@echo off
setlocal enabledelayedexpansion
REM Build all Z43ORAM experimental programs.
REM Auto-detects Visual Studio 2022/2025/2026 if not already configured.

cd /d "%~dp0\src"

where cl >nul 2>nul
if errorlevel 1 (
    echo MSVC compiler not in PATH. Searching for Visual Studio...
    for %%v in (2022 2025 2026) do (
        for %%e in (Community Professional Enterprise) do (
            set "VSPATH=%ProgramFiles%\Microsoft Visual Studio\%%v\%%e\VC\Auxiliary\Build\vcvars64.bat"
            if exist "!VSPATH!" (
                echo Found: !VSPATH!
                call "!VSPATH!" >nul 2>&1
                goto :found
            )
        )
    )
    REM Also check VS Preview / BuildTools
    for %%v in (2022 2025 2026) do (
        set "VSPATH=%ProgramFiles%\Microsoft Visual Studio\%%v\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
        if exist "!VSPATH!" (
            echo Found: !VSPATH!
            call "!VSPATH!" >nul 2>&1
            goto :found
        )
    )
    echo ERROR: Visual Studio 2022/2025/2026 not found.
    echo Please install Visual Studio with C++ workload, or run vcvars64.bat manually.
    pause
    exit /b 1
)
:found

echo ================================================================
echo   Building all Z43ORAM programs
echo ================================================================

set FAILED=0

for %%f in (
    z3_run3 z2_run3 z43_run3 z43_L11_run3 z4_run3 z5_run3
    z43_alt1_L26 z43_alt2_L26 z43_alt3_L26 z43_alt4_L26
    z31_L3to10 z431_security occ
) do (
    echo.
    echo --- Building %%f ---
    cl /O2 /std:c++20 /EHsc /nologo /utf-8 /Fe:%%f.exe %%f.cpp
    if !ERRORLEVEL! neq 0 set /a FAILED+=1
)

echo.
echo ================================================================
echo   Build complete: !FAILED! failure(s)
echo ================================================================
pause
