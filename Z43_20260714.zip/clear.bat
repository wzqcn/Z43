@echo off
cd /d "%~dp0"
echo Cleaning generated files...

REM Object files
del /q src\*.obj 2>nul

REM Executables
del /q src\*.exe 2>nul

REM Experimental output
del /q exp_data\*.txt 2>nul

REM Generated figures
del /q *.pdf 2>nul

echo Done.
pause
