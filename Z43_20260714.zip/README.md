# Z43ORAM: Reproducibility Package

This directory contains all source code to reproduce the figures and tables in:

> **Z43ORAM: Breaking the Z >= 5 Barrier in Path ORAM**  
> ACM SIGMOD 2027

---

## Requirements

- **Compiler**: Microsoft Visual Studio 2022 (MSVC) with C++20 support (`/std:c++20`)
- **OS**: Windows 10/11 (64-bit)

All C++ programs are compiled via `compile_*.bat` scripts in `src/`.
Set up your Visual Studio environment first (e.g., run `vcvars64.bat` or open a Developer Command Prompt).

---

## File Structure

```
20260714/
  README.md          this file
  clear.bat          remove all generated files (*.obj, *.exe, *.txt, *.pdf)
  src/               all source code and compile scripts
  exp_data/          experimental output files (generated at runtime)
  *.pdf              generated figures
```

---

## Figure → Code Mapping (data source)

Figure data arrays embedded in the paper's plotting script were obtained from the following programs.

| Figure | Description | Data Source | Key Parameters |
|--------|-------------|-------------|----------------|
| Fig 1 (Z=2,3 stash) | Stash size vs. L for Z=2,3 | `z2_run3.cpp`, `z3_run3.cpp` | `z3_run3.exe 4000000 1` |
| Fig 4 (Z43 stash) | Z43ORAM stash at various L0 | `z43_run3.cpp`, `z43_L11_run3.cpp` | L0=8/9/10/11/12 |
| Fig 6 (Z3 vs Z43) | Z3 and Z43ORAM comparison | `z3_run3.cpp`, `z43_run3.cpp`, `z43_L11_run3.cpp` | L=8..26 |
| Fig 7 (Z3 detail) | Z3 stash statistics | `z3_run3.cpp` | L=8..26 |
| Fig 9 (Z3 predicted) | Z3 predicted vs. actual | `z3_run3.cpp` | L=17..22, 4M reads |
| Figs 10-12 (occupancy) | Per-level occupancy | `occ.cpp` | L=18, 50M reads |

---

## Table → Code Mapping

| Table | Description | C++ Program / Script | Key Command |
|-------|-------------|---------------------|-------------|
| tab:z2z3 | Z=3 stash data L=3..26 | `z3_run3.cpp` | `z3_run3.exe 4000000 1` |
| tab:z43 | Z43ORAM stash (L0=8,11) | `z43_run3.cpp`, `z43_L11_run3.cpp` | `z43_run3.exe 4000000 1` |
| tab:z43variant | Z43 alternating variants | `z43_alt1_L26.cpp`, `z43_alt2_L26.cpp`, `z43_alt3_L26.cpp`, `z43_alt4_L26.cpp` | L=26, 50M reads |
| tab:z31 | Z=(3,1) stash data | `z31_L3to10.cpp` | L=3..10, 4M reads |
| tab:lambda | Theoretical security levels | `fixed_points.py` | Theoretical (RSAE+MGF) |
| tab:Emax | Expected maximum stash | `fixed_points.py` | Theoretical (RSAE+MGF) |
| tab:security_compare | Security comparison | — (computed analytically) | N/A |
| tab:z431security | Z431 empirical security | `z431_security.cpp` | L=20, L0=8, 1 warmup, 2^s reads |

---

## Step-by-Step Reproduction

### 1. Compile All Programs

```
cd src
compile_z3_3.bat
compile_z2_3.bat
compile_z43_3.bat
compile_z43_L11_run3.bat
compile_z4_3.bat
compile_z5_3.bat
compile_z43_alt1_L26.bat
compile_z43_alt2_L26.bat
compile_z43_alt3_L26.bat
compile_z43_alt4_L26.bat
compile_z31_L3to10.bat
compile_z431_security.bat
compile_occ.bat
```

### 2. Run Experiments

Run each program from the `src/` directory. Output files are generated in the current working directory.
Move output text files to `exp_data/` for organization.

**Z=3 stash (Table tab:z2z3, Figures 1,6,7,9):**
```
z3_run3.exe 4000000 1 > exp_data/z3_results.txt
```

**Z=2 stash (Figure 1):**
```
z2_run3.exe > exp_data/z2_results.txt
```

**Z43ORAM (Table tab:z43, Figures 4,6):**
```
z43_run3.exe 4000000 1 > exp_data/z43_results.txt
z43_L11_run3.exe > exp_data/z43_L11_results.txt
```

**Z43 alternating variants (Table tab:z43variant):**
```
z43_alt1_L26.exe > exp_data/z43_alt1_L26.txt
z43_alt2_L26.exe > exp_data/z43_alt2_L26.txt
z43_alt3_L26.exe > exp_data/z43_alt3_L26.txt
z43_alt4_L26.exe > exp_data/z43_alt4_L26.txt
```

**Z31 (Table tab:z31):**
```
z31_L3to10.exe > exp_data/z31_results.txt
```

**Z431 security (Table tab:z431security):**
```
z431_security.exe
```
Output: `z431_security_results.txt`

**Occupancy (Figures 10-12):**
```
occ.exe > exp_data/occ_results.txt
```

### 3. Verify Theoretical Tables

```
cd src
python fixed_points.py
```

---

## Cleanup

Run `clear.bat` from the project root to delete all generated files (`.obj`, `.exe`, `.txt`, `.pdf`).

---

## Notes

- All C++ programs use fixed random seeds for exact reproducibility. Seed formulas are documented in each source file.
- Large experiments (L>=23 for Z=3) require significant memory and runtime (hours on a desktop CPU).
- The Z=4 and Z=5 baseline data in Table tab:z43 come from `z4_run3.cpp` and `z5_run3.cpp`, included for completeness.
