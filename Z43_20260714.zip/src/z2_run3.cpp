/**
 * Z2_RUN3 — worst-case cyclic access, Z=2, beta=1/2
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z2_run3.exe z2_run3.cpp
 * Usage:   z2_run3.exe [total_reads] [warmup_rounds]
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>

using namespace std;

class PathORAM {
public:
    int L, Z, N, num_blocks;
    double beta;
    unordered_map<int, int> stash;
    vector<int> pos_map;
    vector<vector<pair<int,int>>> tree;
    unordered_map<int, unordered_set<int>> cand;
    mt19937_64 rng;
    uniform_int_distribution<int> leaf_dist;

    PathORAM(int L_, int Z_, double beta_, uint64_t seed)
        : L(L_), Z(Z_), beta(beta_), rng(seed)
    {
        N = (1 << L) - 1;
        num_blocks = max(1, (int)(N * beta));
        tree.resize(N + 1);
        pos_map.resize(num_blocks);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));
        for (int bid = 0; bid < num_blocks; bid++) {
            int leaf = leaf_dist(rng);
            pos_map[bid] = leaf;
            stash[bid] = leaf;
        }
        rebuild_cand();
        evict_all();
    }

    vector<int> get_path(int leaf) const {
        vector<int> path(L);
        int node = 1;
        for (int lev = 0; lev < L; lev++) {
            path[lev] = node;
            if (lev < L - 1) {
                if ((leaf >> (L - 2 - lev)) & 1)
                    node = 2 * node + 1;
                else
                    node = 2 * node;
            }
        }
        return path;
    }

    void rebuild_cand() {
        cand.clear();
        for (auto& kv : stash) {
            int bid = kv.first, lf = kv.second;
            auto p = get_path(lf);
            for (int node : p) cand[node].insert(bid);
        }
    }
    void cand_add(int bid, int leaf) {
        auto p = get_path(leaf);
        for (int node : p) cand[node].insert(bid);
    }
    void cand_remove(int bid, int leaf) {
        auto p = get_path(leaf);
        for (int node : p) {
            auto it = cand.find(node);
            if (it != cand.end()) it->second.erase(bid);
        }
    }
    void cand_update(int bid, int old_leaf, int new_leaf) {
        auto p_old = get_path(old_leaf);
        auto p_new = get_path(new_leaf);
        for (int node : p_old) {
            auto it = cand.find(node);
            if (it != cand.end()) it->second.erase(bid);
        }
        for (int node : p_new) cand[node].insert(bid);
    }

    void evict_all() {
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node]) {
                if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            }
            tree[node].clear();
        }
        for (int lev = L - 1; lev >= 0; lev--) {
            int first = 1 << lev;
            int last  = min((1 << (lev + 1)) - 1, N);
            for (int node = first; node <= last; node++) {
                auto it = cand.find(node);
                if (it == cand.end()) continue;
                int taken = 0;
                vector<int> to_evict;
                for (int bid : it->second) {
                    if (taken >= Z) break;
                    if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
                }
                for (int bid : to_evict) {
                    int lf = stash[bid];
                    tree[node].push_back({bid, lf});
                    stash.erase(bid);
                    cand_remove(bid, lf);
                }
            }
        }
    }

    int access(int block_id) {
        int old_leaf = (block_id < num_blocks) ? pos_map[block_id] : leaf_dist(rng);
        int new_leaf = leaf_dist(rng);
        if (block_id < num_blocks) pos_map[block_id] = new_leaf;

        auto path = get_path(old_leaf);
        for (int node : path) {
            for (auto& [bid, lf] : tree[node]) {
                if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            }
            tree[node].clear();
        }
        if (stash.count(block_id)) {
            int old_lf = stash[block_id];
            cand_update(block_id, old_lf, new_leaf);
            stash[block_id] = new_leaf;
        } else {
            stash[block_id] = new_leaf;
            cand_add(block_id, new_leaf);
        }
        for (int i = (int)path.size() - 1; i >= 0; i--) {
            int node = path[i];
            auto it = cand.find(node);
            if (it == cand.end()) continue;
            int taken = 0;
            vector<int> to_evict;
            for (int bid : it->second) {
                if (taken >= Z) break;
                if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
            }
            for (int bid : to_evict) {
                int lf = stash[bid];
                tree[node].push_back({bid, lf});
                stash.erase(bid);
                cand_remove(bid, lf);
            }
        }
        return (int)stash.size();
    }
};

int main(int argc, char* argv[]) {
    int total_reads = (argc >= 2) ? atoi(argv[1]) : 4000000;
    int warm_rounds = (argc >= 3) ? atoi(argv[2]) : 1;

    const char* outfile = "z2_run3_results.txt";
    FILE* fout = fopen(outfile, "w");
    if (!fout) { fprintf(stderr, "Cannot open %s\n", outfile); return 1; }

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    fprintf(fout, "================================================================\n");
    fprintf(fout, "  Z=2 RUN3 (worst-case cyclic)  beta=1/2  warmup_rounds=%d  total_reads=%d\n",
            warm_rounds, total_reads);
    fprintf(fout, "  Started: %s\n", timebuf);
    fprintf(fout, "================================================================\n\n");
    fflush(fout);

    printf("Z2_RUN3 (worst-case cyclic)  warmup=%d rounds  measure=%d reads\n\n",
           warm_rounds, total_reads);
    printf("%-4s %10s %10s %10s %10s %10s %8s %8s\n", "L", "avg", "max", "min", "sigma", "blocks", "cycles", "time(s)");
    printf("---- ---------- ---------- ---------- ---------- ---------- -------- --------\n");

    fprintf(fout, "%-4s %10s %10s %10s %10s %10s %8s %8s\n", "L", "avg", "max", "min", "sigma", "blocks", "cycles", "time(s)");
    fprintf(fout, "---- ---------- ---------- ---------- ---------- ---------- -------- --------\n");
    fflush(fout);

    for (int L = 3; L <= 22; L++) {
        fprintf(stderr, "L=%d...", L); fflush(stderr);

        auto t0 = chrono::steady_clock::now();
        PathORAM oram(L, 2, 1.0 / 2, (uint64_t)L * 100 + 2);
        int Nb = oram.num_blocks;

        // ---- Warmup: cyclic rounds ----
        for (int r = 0; r < warm_rounds; r++)
            for (int bid = 0; bid < Nb; bid++)
                oram.access(bid);

        // ---- Measure: cyclic reads (worst-case pattern) ----
        vector<int> sizes;
        sizes.reserve(total_reads);

        auto last_report = t0;
        for (int i = 0; i < total_reads; i++) {
            int bid = i % Nb;  // cyclic, not random — worst-case access pattern
            sizes.push_back(oram.access(bid));

            // ---- ETA for long L (no timeout, just estimate) ----
            auto t_now = chrono::steady_clock::now();
            double elapsed_since_report = chrono::duration<double>(t_now - last_report).count();
            if (elapsed_since_report > 600.0 && i > 10000) {
                double elapsed_total = chrono::duration<double>(t_now - t0).count();
                double rate = i / elapsed_total;
                double remaining = (total_reads - i) / rate;
                int h = (int)(remaining / 3600);
                int m = (int)((remaining - h * 3600) / 60);
                fprintf(stderr, " [%d/%d reads, ETA %dh%02dm]", i, total_reads, h, m);
                fflush(stderr);
                last_report = t_now;
            }
        }

        int n = (int)sizes.size();
        double sum = 0, sumsq = 0, mxv = sizes[0], mnv = sizes[0];
        for (int s : sizes) { sum += s; sumsq += (double)s * s; if (s > mxv) mxv = s; if (s < mnv) mnv = s; }
        double avg = sum / n;
        double sigma = sumsq / n - avg * avg;
        if (sigma < 0) sigma = 0;
        double cycles = (double)n / Nb;

        auto t1 = chrono::steady_clock::now();
        double elapsed = chrono::duration<double>(t1 - t0).count();

        printf("%-4d %10.4f %10.1f %10.1f %10.4f %10d %7.1f %8.1f\n", L, avg, mxv, mnv, sigma, Nb, cycles, elapsed);
        fprintf(fout, "%-4d %10.4f %10.1f %10.1f %10.4f %10d %7.1f %8.1f\n", L, avg, mxv, mnv, sigma, Nb, cycles, elapsed);
        fflush(fout);

        fprintf(stderr, " done (avg=%.4f sigma=%.4f, %.1fs, %.1f cycles)\n", avg, sigma, elapsed, cycles);
    }

    fprintf(fout, "\nDone.\n");
    fclose(fout);
    printf("\nResults saved to %s\n", outfile);
    return 0;
}
