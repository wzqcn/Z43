/**
 * Z43ORAM L0=11 — RUN3: L=8..20, 4M cyclic reads, same seed as L0=8.
 *
 * Seed = L*100+43 (same formula used by z43_run3 for all L0).
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z43_L11_run3.exe z43_L11_run3.cpp
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

class PathORAM {
public:
    int L, L0, N, num_blocks;
    double beta;
    unordered_map<int, int> stash;
    unordered_map<int, int> pos_map;
    vector<vector<pair<int,int>>> tree;
    unordered_map<int, unordered_set<int>> cand;
    mt19937_64 rng;
    uniform_int_distribution<int> leaf_dist;

    PathORAM(int L_, double beta_, uint64_t seed, int L0_ = 8)
        : L(L_), beta(beta_), L0(L0_), rng(seed) {
        N = (1 << L) - 1;
        num_blocks = max(1, (int)(N * beta));
        tree.resize(N + 1);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));
        for (int bid = 0; bid < num_blocks; bid++) {
            int leaf = leaf_dist(rng);
            pos_map[bid] = leaf;
        }
        rebuild_cand();
        evict_all();
    }

    int get_Z(int lev) const {
        return (lev >= L - L0) ? 3 : 4;
    }

    vector<int> get_path(int leaf) const {
        vector<int> path(L);
        int node = 1;
        for (int lev = 0; lev < L; lev++) {
            path[lev] = node;
            if (lev < L - 1) {
                if ((leaf >> (L - 2 - lev)) & 1) node = 2*node+1;
                else node = 2*node;
            }
        }
        return path;
    }

    void rebuild_cand() {
        cand.clear();
        for (auto& kv : stash) {
            int bid = kv.first, lf = kv.second;
            auto p = get_path(lf);
            for (int node : p) cand[node].insert(bid);
        }
    }
    void cand_add(int bid, int leaf) {
        auto p = get_path(leaf);
        for (int node : p) cand[node].insert(bid);
    }
    void cand_remove(int bid, int leaf) {
        auto p = get_path(leaf);
        for (int node : p) {
            auto it = cand.find(node);
            if (it != cand.end()) it->second.erase(bid);
        }
    }
    void cand_update(int bid, int old_lf, int new_lf) {
        auto p_old = get_path(old_lf);
        auto p_new = get_path(new_lf);
        for (int node : p_old) {
            auto it = cand.find(node);
            if (it != cand.end()) it->second.erase(bid);
        }
        for (int node : p_new) cand[node].insert(bid);
    }

    void evict_all() {
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node])
                if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            tree[node].clear();
        }
        for (int lev = L-1; lev >= 0; lev--) {
            int Z_here = get_Z(lev);
            int first = 1 << lev;
            int last = min((1<<(lev+1))-1, N);
            for (int node = first; node <= last; node++) {
                auto it = cand.find(node);
                if (it == cand.end()) continue;
                int taken = 0;
                vector<int> to_evict;
                for (int bid : it->second) {
                    if (taken >= Z_here) break;
                    if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
                }
                for (int bid : to_evict) {
                    int lf = stash[bid];
                    tree[node].push_back({bid, lf});
                    stash.erase(bid);
                    cand_remove(bid, lf);
                }
            }
        }
    }

    int access(int block_id) {
        int old_lf = (block_id < num_blocks) ? pos_map[block_id] : leaf_dist(rng);
        int new_lf = leaf_dist(rng);
        if (block_id < num_blocks) pos_map[block_id] = new_lf;
        auto path = get_path(old_lf);
        for (int node : path) {
            for (auto& [bid, lf] : tree[node])
                if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            tree[node].clear();
        }
        if (stash.count(block_id)) {
            int old = stash[block_id];
            cand_update(block_id, old, new_lf);
            stash[block_id] = new_lf;
        } else {
            stash[block_id] = new_lf;
            cand_add(block_id, new_lf);
        }
        for (int i = (int)path.size()-1; i >= 0; i--) {
            int node = path[i], Z_here = get_Z(i);
            auto it = cand.find(node);
            if (it == cand.end()) continue;
            int taken = 0;
            vector<int> to_evict;
            for (int bid : it->second) {
                if (taken >= Z_here) break;
                if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
            }
            for (int bid : to_evict) {
                int lf = stash[bid];
                tree[node].push_back({bid, lf});
                stash.erase(bid);
                cand_remove(bid, lf);
            }
        }
        return (int)stash.size();
    }
};

int main() {
    int L0 = 11, warm_rd = 1;
    long long total = 4000000LL;
    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    FILE* flog = fopen("z43_L11_run3_results.txt", "w");
    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z43ORAM L0=%d RUN3  L=8..20  4M cyclic reads\n", L0);
    fprintf(flog, "  Seed: L*100+43 (same as L0=8 z43_run3)\n");
    fprintf(flog, "  Started: %s\n", tbuf);
    fprintf(flog, "================================================================\n\n");
    fprintf(flog, "%-4s %10s %10s %10s %10s %8s %8s\n",
            "L", "avg", "max", "min", "sigma", "cycles", "time");
    fflush(flog);

    printf("================================================================\n");
    printf("  Z43ORAM L0=%d RUN3  L=8..20  4M reads  warm=%d\n", L0, warm_rd);
    printf("  Seed: L*100+43 (same as L0=8)\n");
    printf("================================================================\n\n");

    for (int L = 8; L <= 20; L++) {
        long long N_est = (1LL << L) - 1;
        printf("\n--- L=%d  N_est=%lld ---\n", L, N_est);
        printf("  Z: ");
        for (int li = 0; li < L; li++)
            printf("%d", (L-1-li < L0) ? 3 : 4);
        printf("\n"); fflush(stdout);

        fprintf(flog, "\n--- L=%d  N_est=%lld ---\n", L, N_est);
        fflush(flog);

        auto t0 = chrono::steady_clock::now();
        PathORAM oram(L, 1.0/3, (uint64_t)L*100 + 43, L0);
        int Nb = oram.num_blocks;

        printf("  Warmup (%d blocks, 1 round)...\n", Nb); fflush(stdout);
        for (int bid = 0; bid < Nb; bid++) oram.access(bid);

        // Measurement
        t0 = chrono::steady_clock::now();
        double sum = 0, sumsq = 0, mx = 0, mn = 1e9;
        long long REPORT = max(1LL, total/50);
        long long LOG = max(1LL, total/10);

        for (long long i = 0; i < total; i++) {
            int st = oram.access(i % Nb);
            sum += st; sumsq += (double)st*st;
            if (st > mx) mx = st; if (st < mn) mn = st;

            if (i>0 && i%REPORT == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2-t0).count();
                double remain = (total-i)/(i/el);
                int rh=(int)(remain/3600), rm=(int)((remain-rh*3600)/60);
                double avg = sum/i, var = sumsq/i-avg*avg;
                if (var<0) var=0;
                printf("\r  [%lld/4M] avg=%.4f sig=%.4f max=%.0f %4.0fs ETA %dh%02dm stash=%zu",
                       i/100000, avg, sqrt(var), mx, el, rh, rm, oram.stash.size());
                fflush(stdout);
            }
            if (i>0 && i%LOG == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2-t0).count();
                double avg = sum/i, var = sumsq/i-avg*avg;
                if (var<0) var=0;
                fprintf(flog, "  [%lld/4M] avg=%.4f sig=%.4f max=%.0f stash=%zu\n",
                        i/100000, avg, sqrt(var), mx, oram.stash.size());
                fflush(flog);
            }
        }
        auto t2 = chrono::steady_clock::now();
        double el = chrono::duration<double>(t2-t0).count();
        double avg = sum/total, var = sumsq/total-avg*avg;
        if (var<0) var=0; double sig = sqrt(var), cycles = (double)total/Nb;

        printf("\r  %-4d %10.4f %10.1f %10.1f %10.4f %7.1f %7.0fs\n",
               L, avg, mx, mn, sig, cycles, el);
        fprintf(flog, "%-4d %10.4f %10.1f %10.1f %10.4f %7.1f %7.0fs\n",
                L, avg, mx, mn, sig, cycles, el);
        fflush(flog);
    }

    now = chrono::system_clock::now(); tt = chrono::system_clock::to_time_t(now);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    fprintf(flog, "\n=== Finished: %s ===\n", tbuf); fclose(flog);
    printf("\n=== Done. Log: z43_L11_run3_results.txt ===\n");
    return 0;
}
