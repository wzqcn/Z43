@echo off
REM Run "Developer Command Prompt for VS 2022" or vcvars64.bat before executing.
cd /d "%~dp0"
cl /O2 /std:c++20 /EHsc /nologo /utf-8 /Fe:z4_run3.exe z4_run3.cpp
if %ERRORLEVEL% equ 0 (echo Build OK: z4_run3.exe) else (echo Build FAILED)
pause
