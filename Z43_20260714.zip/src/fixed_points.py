"""
Fixed-point analysis of f_Z(x) for Z = 4, 5, 6.

f_Z(x) = E(X_{L+1}) upper bound given E(X_L) = x, from the RSAE + MGF framework.
A fixed point satisfies x = f_Z(x), i.e., the expected stash is self-consistent.

Formula (Theorem 1 / Lemma lem:mgf):
    alpha(x) = ln(Z / (1 + 2x))
    b(x)     = (1 + 2x) + Z * ln(Z / (1 + 2x)) - Z
    f_Z(x)   = exp(-b(x)) / alpha(x)

Domain: x in [0, (Z-1)/2)   (so that alpha > 0, i.e., Z > 1 + 2x)

A fixed point zeta satisfies: zeta = f_Z(zeta).

References:
  Z43ORAM paper (SIGMOD 2027), Sections 4--5.
"""

import numpy as np
from scipy.optimize import fsolve
import sys

# ---------------------------------------------------------------------------
def alpha(Z, x):
    """Exponential decay rate."""
    return np.log(Z / (1.0 + 2.0 * x))

def b_val(Z, x):
    """Shift constant in the tail bound."""
    return (1.0 + 2.0 * x) + Z * np.log(Z / (1.0 + 2.0 * x)) - Z

def f_Z(Z, x):
    """Fixed-point function f_Z(x) = E(X_{L+1}) upper bound."""
    a = alpha(Z, x)
    return np.exp(-b_val(Z, x)) / a

# ---------------------------------------------------------------------------
def find_fixed_points(Z):
    """Find all fixed points of f_Z in domain [0, (Z-1)/2)."""
    x_max = (Z - 1.0) / 2.0   # domain upper bound (alpha -> 0+)

    print(f"{'='*70}")
    print(f"  Z = {Z}    domain: [0, {x_max:.6f})")
    print(f"{'='*70}")

    # --- First fixed point (small): near 0 ---
    # f_Z(0) = exp(-b(0)) / alpha(0)
    # alpha(0) = ln(Z)
    # b(0) = 1 + Z*ln(Z) - Z
    # f_Z(0) = exp(-1 - Z*ln(Z) + Z) / ln(Z) = exp(Z-1) / (Z^Z * ln(Z))
    f0 = f_Z(Z, 1e-12)
    print(f"  f_Z(0+)    = {f0:.6f}")

    # First fixed point: solve near 0
    # For Z >= 4, f_Z(0) > 0, and there's a small fixed point.
    # For Z = 3, f_Z(0) > 0 but function may not cross y=x.
    zeta1_guess = f0 * 1.1 if f0 > 0 else 0.01
    try:
        zeta1 = fsolve(lambda x: f_Z(Z, x) - x, zeta1_guess, maxfev=200)[0]
        if 0 < zeta1 < x_max:
            f1 = f_Z(Z, zeta1)
            err1 = abs(f1 - zeta1)
            status1 = "converged" if err1 < 1e-10 else f"residual={err1:.2e}"
        else:
            zeta1, status1 = None, "out of domain"
    except Exception as e:
        zeta1, status1 = None, str(e)[:40]

    if zeta1 is not None:
        a1 = alpha(Z, zeta1)
        b1 = b_val(Z, zeta1)
        print(f"  zeta_{Z}    = {zeta1:.6f}   ({status1})")
        print(f"    alpha = {a1:.6f}")
        print(f"    b     = {b1:.6f}")
        print(f"    e^b   = {np.exp(b1):.4f}")
        # actual overflow probability at R
        for R in [64, 128, 200]:
            pr = np.exp(-a1 * R - b1)
            print(f"    Pr[ X > {R:3d} ] <= exp(-{a1:.4f}*{R} - {b1:.4f}) = {pr:.2e}")
    else:
        print(f"  zeta_{Z}    = NONE  ({status1})")

    # --- Second fixed point (large): near domain boundary ---
    # As x -> x_max, alpha -> 0+, b -> 0+, f_Z -> +inf.
    # Need a large value near x_max - epsilon.
    zeta2_guess = x_max * 0.5 if zeta1 is None else (zeta1 + x_max) / 2.0
    try:
        zeta2 = fsolve(lambda x: f_Z(Z, x) - x, zeta2_guess, maxfev=200)[0]
        if 0 < zeta2 < x_max and (zeta1 is None or abs(zeta2 - zeta1) > 1e-6):
            f2 = f_Z(Z, zeta2)
            err2 = abs(f2 - zeta2)
            status2 = "converged" if err2 < 1e-10 else f"residual={err2:.2e}"
        else:
            zeta2, status2 = None, "degenerate with zeta1"
    except Exception as e:
        zeta2, status2 = None, str(e)[:40]

    if zeta2 is not None:
        a2 = alpha(Z, zeta2)
        b2 = b_val(Z, zeta2)
        print(f"  zeta_{Z}'   = {zeta2:.6f}   ({status2})")
        print(f"    alpha = {a2:.6f}")
        print(f"    b     = {b2:.6f}")
        print(f"    e^b   = {np.exp(b2):.4f}")
        for R in [64, 128, 200]:
            pr = np.exp(-a2 * R - b2)
            print(f"    Pr[ X > {R:3d} ] <= exp(-{a2:.4f}*{R} - {b2:.4f}) = {pr:.2e}")
    else:
        print(f"  zeta_{Z}'   = NONE  ({status2})")

    # --- Print fixed-point function table ---
    print(f"\n  {'x':>10s}  {'f_{}(x)'.format(Z):>12s}  {'f_Z(x)-x':>12s}  Notes")
    print(f"  {'-'*10}  {'-'*12}  {'-'*12}  {'-'*20}")
    xs = [0.0]
    if zeta1 is not None:
        xs.append(round(zeta1, 4))
    if zeta2 is not None:
        xs.append(round(zeta2, 4))
    xs += [0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.60, 0.80, 1.0, 1.5, 2.0]
    xs = sorted(set(x for x in xs if x < x_max))
    for x in xs:
        fx = f_Z(Z, x)
        diff = fx - x
        note = ""
        if zeta1 is not None and abs(x - zeta1) < 0.001:
            note = "<-- zeta (stable)"
        if zeta2 is not None and abs(x - zeta2) < 0.001:
            note = "<-- zeta' (unstable)"
        if abs(diff) < 0.002 and not note:
            note = "<-- near crossing"
        print(f"  {x:10.6f}  {fx:12.8f}  {diff:+12.8f}  {note}")

    print()
    return zeta1, zeta2


# ---------------------------------------------------------------------------
def main():
    print("=" * 70)
    print("  Fixed-Point Analysis of f_Z(x)  (RSAE + MGF Framework)")
    print("  Z43ORAM paper — Sections 4--5")
    print("=" * 70)
    print()

    results = {}
    for Z in [4, 5, 6]:
        z1, z2 = find_fixed_points(Z)
        results[Z] = (z1, z2)

    # --- Also check Z=3 (no fixed point) ---
    print(f"{'='*70}")
    print(f"  Z = 3    domain: [0, 1.0)")
    print(f"{'='*70}")
    xs = np.linspace(0.001, 0.99, 20)
    all_above = True
    for x in xs:
        fx = f_Z(3, x)
        if fx <= x:
            all_above = False
            print(f"  f_3({x:.4f}) = {fx:.6f} <= {x:.4f}  <- would cross!")
    if all_above:
        print(f"  f_3(x) > x for all x in [0,1) — NO fixed point (Z=3 is unbounded).")
    print()

    # --- Comparison table ---
    print(f"{'='*70}")
    print(f"  Summary: Fixed Points and Security Parameters")
    print(f"{'='*70}")
    print(f"  {'Z':>3s}  {'zeta':>10s}  {'alpha':>8s}  {'b':>8s}  {'e^b':>8s}  {'Pr>64':>10s}  {'Pr>128':>10s}  {'Pr>200':>10s}")
    print(f"  {'-'*3}  {'-'*10}  {'-'*8}  {'-'*8}  {'-'*8}  {'-'*10}  {'-'*10}  {'-'*10}")
    for Z in [4, 5, 6]:
        zeta = results[Z][0]  # first (stable) fixed point
        if zeta is not None:
            a = alpha(Z, zeta)
            b = b_val(Z, zeta)
            eb = np.exp(b)
            pr64 = np.exp(-a * 64 - b)
            pr128 = np.exp(-a * 128 - b)
            pr200 = np.exp(-a * 200 - b)
            print(f"  {Z:3d}  {zeta:10.6f}  {a:8.4f}  {b:8.4f}  {eb:8.2f}  {pr64:10.2e}  {pr128:10.2e}  {pr200:10.2e}")
    print()
    print(f"  For Z=4, the second fixed point zeta_4' = {results[4][1]:.6f}")
    print(f"  For Z=5, the second fixed point zeta_5' = {results[5][1]:.6f}")
    print(f"  For Z=6, the second fixed point zeta_6' = {results[6][1]:.6f}")
    print()

    # --- Interpretation ---
    print(f"{'='*70}")
    print(f"  Interpretation")
    print(f"{'='*70}")
    print(f"""
  1. First fixed point (zeta): stable attractor.
     - The RSAE induction converges to this value from below.
     - E(X_L) <= zeta for all L (provable bound).
     - Smaller zeta => smaller provable stash => better security.

  2. Second fixed point (zeta'): unstable.
     - If the stash EVER exceeds zeta', the RSAE induction diverges
       (f_Z amplifies rather than contracts).
     - zeta' marks the limit of what the current proof technique can certify.
     - Configurations between zeta and zeta' may still converge in practice
       (experimental observation), but cannot be proven with the current framework.

  3. Z=4: zeta_4={results[4][0]:.4f}, zeta_4'={results[4][1]:.4f}
     Proven secure. This paper's main result.

  4. Z=5: zeta_5={results[5][0]:.4f}, zeta_5'={results[5][1]:.4f}
     Original Path ORAM paper result. Much smaller zeta but larger Z cost.

  5. Z=6: zeta_6={results[6][0]:.4f}, zeta_6'={results[6][1]:.4f}
     Even tighter bound — diminishing returns.

  6. Z=3: NO fixed point. f_3(x) > x for all x. Stash grows without bound
     for sufficiently large L (exponential growth formula, Theorem 3).
    """)

    print("=" * 70)
    print("  Done.")
    print("=" * 70)


if __name__ == "__main__":
    main()
