@echo off
REM Set up Visual Studio environment before running, e.g.:
REM   "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
REM Or open a "Developer Command Prompt for VS 2022" and run this script from there.
cd /d "%~dp0"
cl /O2 /std:c++20 /EHsc /nologo /utf-8 /Fe:z431_security.exe z431_security.cpp
if %ERRORLEVEL% equ 0 (echo Build OK) else (echo Build FAILED)
pause
