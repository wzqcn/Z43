/**
 * occ.cpp — Z3 / Z43 / Z431 Per-Level Occupancy, L=18, 50M reads each
 * Standard Path ORAM interface: access(op, address, data)
 *   op=0: read  (returns old data)
 *   op=1: write (returns old stash size)
 * Level numbering: level 1 = root, level L = leaf.
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:occ.exe occ.cpp
 * Usage:   occ.exe [L] [total_reads_millions] [warmup_rounds]
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

// Global stash size for external access
int g_stash_size = 0;

class ZORAM {
public:
    int L, N, num_blocks;
    double beta;
    vector<int> Z_per_level;       // Z_per_level[0]=root, Z_per_level[L-1]=leaf
    unordered_map<int, int> stash;       // bid -> leaf
    unordered_map<int, int> stash_data;  // bid -> data value
    vector<int> pos_map;
    vector<vector<pair<int,int>>> tree;  // (bid, leaf), bid=-1=dummy
    unordered_map<int, unordered_set<int>> cand;
    vector<long long> level_blocks;
    vector<long long> level_accum;
    vector<long long> level_samples;
    mt19937_64 rng;
    uniform_int_distribution<int> leaf_dist;

    ZORAM(int L_, const vector<int>& Zvec, double beta_, uint64_t seed)
        : L(L_), Z_per_level(Zvec), beta(beta_), rng(seed)
    {
        N = (1 << L) - 1;
        num_blocks = max(1, (int)(N * beta));
        tree.resize(N + 1);
        pos_map.resize(num_blocks);
        level_blocks.assign(L, 0);
        level_accum.assign(L, 0);
        level_samples.assign(L, 0);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));
        for (int bid = 0; bid < num_blocks; bid++) {
            int leaf = leaf_dist(rng);
            pos_map[bid] = leaf;
            stash[bid] = leaf;
            stash_data[bid] = bid;  // initial data = block id
        }
        rebuild_cand();
        evict_all();
        g_stash_size = (int)stash.size();
    }

    vector<int> get_path(int leaf) const {
        vector<int> p(L);
        int node = 1;
        for (int lev = 0; lev < L; lev++) {
            p[lev] = node;
            if (lev < L - 1) node = 2 * node + ((leaf >> (L - 2 - lev)) & 1);
        }
        return p;
    }

    void rebuild_cand() {
        cand.clear();
        for (auto& kv : stash) {
            for (int node : get_path(kv.second))
                cand[node].insert(kv.first);
        }
    }
    void cand_add(int bid, int leaf) {
        for (int node : get_path(leaf)) cand[node].insert(bid);
    }
    void cand_remove(int bid, int leaf) {
        for (int node : get_path(leaf)) cand[node].erase(bid);
    }
    void cand_update(int bid, int old_leaf, int new_leaf) {
        for (int node : get_path(old_leaf)) cand[node].erase(bid);
        for (int node : get_path(new_leaf)) cand[node].insert(bid);
    }

    void evict_all() {
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node])
                if (bid >= 0 && !stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            tree[node].clear();
        }
        for (int li = L - 1; li >= 0; li--) {
            int first = 1 << li, last = min((1 << (li + 1)) - 1, N);
            for (int node = first; node <= last; node++) {
                int Zn = Z_per_level[li], taken = 0;
                vector<int> to_evict;
                for (int bid : cand[node]) {
                    if (taken >= Zn) break;
                    if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
                }
                for (int bid : to_evict) {
                    int lf = stash[bid];
                    tree[node].push_back({bid, lf});
                    stash.erase(bid);
                    cand_remove(bid, lf);
                }
                while ((int)tree[node].size() < Zn)
                    tree[node].push_back({-1, -1});
                level_blocks[li] += taken;
            }
        }
    }

    // Standard Path ORAM access: op=0 read (returns data), op=1 write (returns old size)
    int access(int op, int block_id, int new_data) {
        int old_leaf = (block_id < num_blocks) ? pos_map[block_id] : leaf_dist(rng);
        int new_leaf = leaf_dist(rng);
        if (block_id < num_blocks) pos_map[block_id] = new_leaf;

        auto path = get_path(old_leaf);
        // ReadPath
        for (int li = 0; li < L; li++) {
            int node = path[li], real_cnt = 0;
            for (auto& [bid, lf] : tree[node]) {
                if (bid >= 0) {
                    if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
                    real_cnt++;
                }
            }
            level_blocks[li] -= real_cnt;
            tree[node].clear();
        }
        // Get old data
        int result = -1;
        auto it = stash_data.find(block_id);
        if (it != stash_data.end()) {
            result = it->second;
            int old_lf = stash[block_id];
            cand_update(block_id, old_lf, new_leaf);
            stash[block_id] = new_leaf;
            stash_data[block_id] = (op == 1) ? new_data : result;
        } else {
            stash[block_id] = new_leaf;
            stash_data[block_id] = (op == 1) ? new_data : block_id;
            cand_add(block_id, new_leaf);
        }
        // EvictPath leaf-to-root
        for (int i = (int)path.size() - 1; i >= 0; i--) {
            int node = path[i], lev = i, Zn = Z_per_level[lev];
            auto it2 = cand.find(node);
            if (it2 == cand.end()) continue;
            int taken = 0;
            vector<int> to_evict;
            for (int bid : it2->second) {
                if (taken >= Zn) break;
                if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
            }
            for (int bid : to_evict) {
                int lf = stash[bid];
                tree[node].push_back({bid, lf});
                stash.erase(bid);
                cand_remove(bid, lf);
            }
            while ((int)tree[node].size() < Zn)
                tree[node].push_back({-1, -1});
            level_blocks[lev] += taken;
        }
        g_stash_size = (int)stash.size();
        return result;
    }

    void record_occupancy() {
        for (int li = 0; li < L; li++) {
            level_accum[li] += level_blocks[li];
            level_samples[li]++;
        }
    }

    double get_occupancy(int li) const {
        if (level_samples[li] == 0) return 0;
        return (double)level_accum[li] / level_samples[li];
    }
};

vector<int> make_Z_uniform(int L, int Z) { return vector<int>(L, Z); }
vector<int> make_Z43(int L, int L0) {
    vector<int> Z(L);
    for (int li = 0; li < L; li++) {
        int h = L - 1 - li;
        Z[li] = (h < L0) ? 3 : 4;
    }
    return Z;
}
vector<int> make_Z431(int L, int L0) {
    vector<int> Z(L);
    for (int li = 0; li < L; li++) {
        int h = L - 1 - li;
        if (h == 0) Z[li] = 1; else if (h < L0) Z[li] = 3; else Z[li] = 4;
    }
    return Z;
}

int main(int argc, char* argv[]) {
    int L = (argc >= 2) ? atoi(argv[1]) : 18;
    int reads_M = (argc >= 3) ? atoi(argv[2]) : 50;
    int warm_rd = (argc >= 4) ? atoi(argv[3]) : 1;
    int L0 = 8;
    double beta = 1.0 / 3.0;
    long long total_reads = (long long)reads_M * 1000000;
    int Nb = max(1, (int)(((1 << L) - 1) * beta));
    uint64_t seed_base = 12345;

    char outfile[256];
    sprintf(outfile, "occ_L%d_results.txt", L);
    FILE* fout = fopen(outfile, "a");  // append mode

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    fprintf(fout, "\n================================================================\n");
    fprintf(fout, "=== Occupancy Experiment ===\n");
    fprintf(fout, "  Started: %s\n", timebuf);
    fprintf(fout, "  Configs: Z3, Z43(L0=%d), Z431(L0=%d)\n", L0, L0);
    fprintf(fout, "  L=%d  total_reads=%dM  warmup_rounds=%d  beta=%.4f  blocks=%d\n",
            L, reads_M, warm_rd, beta, Nb);
    fprintf(fout, "  level 1 = root, level %d = leaf\n", L);
    fprintf(fout, "================================================================\n\n");
    fprintf(fout, "%-6s %8s %8s %8s %6s %8s\n", "config", "avg", "max", "sigma", "reads", "time");
    fprintf(fout, "------ -------- -------- -------- ------ --------\n");
    printf("Occupancy: L=%d  reads=%dM  warmup=%d  blocks=%d\n\n", L, reads_M, warm_rd, Nb);
    printf("%-6s %8s %8s %8s %6s %8s\n", "config", "avg", "max", "sigma", "reads", "time");
    printf("------ -------- -------- -------- ------ --------\n");

    auto Z3   = make_Z_uniform(L, 3);
    auto Z43  = make_Z43(L, L0);
    auto Z431 = make_Z431(L, L0);

    // ---- Self-test: write 10000 blocks, read back, verify ----
    printf("Self-test: write/read %d blocks...\n", min(10000, Nb));
    fflush(stdout);
    {
        ZORAM test_oram(L, Z3, beta, seed_base + 999);
        int test_n = min(10000, Nb);
        for (int bid = 0; bid < test_n; bid++)
            test_oram.access(1, bid, bid * 100 + 1);  // write data = bid*100+1
        int errs = 0;
        for (int bid = 0; bid < test_n; bid++) {
            int val = test_oram.access(0, bid, 0);
            if (val != bid * 100 + 1) {
                if (errs < 5) printf("  ERR: bid=%d expected=%d got=%d\n", bid, bid*100+1, val);
                errs++;
            }
        }
        if (errs == 0) printf("  Self-test PASSED (%d blocks OK).\n\n", test_n);
        else { printf("  Self-test FAILED: %d errors. Aborting.\n", errs); return 1; }
        fflush(stdout);
    }

    auto run = [&](const vector<int>& Zvec, const char* label, uint64_t seed) {
        ZORAM oram(L, Zvec, beta, seed);

        // Warmup
        for (int r = 0; r < warm_rd; r++)
            for (int bid = 0; bid < Nb; bid++)
                oram.access(0, bid, 0);

        // Measurement
        auto t0 = chrono::steady_clock::now();
        double sum_st = 0, sumsq_st = 0, max_st = 0, min_st = 1e9;
        for (long long i = 0; i < total_reads; i++) {
            int bid = i % Nb;
            oram.access(0, bid, 0);  // read op
            int st = g_stash_size;
            sum_st += st; sumsq_st += (double)st * st;
            if (st > max_st) max_st = st;
            if (st < min_st) min_st = st;
            oram.record_occupancy();
        }
        auto t1 = chrono::steady_clock::now();
        double elapsed = chrono::duration<double>(t1 - t0).count();
        double avg_st = sum_st / total_reads;
        double var_st = sumsq_st / total_reads - avg_st * avg_st;
        if (var_st < 0) var_st = 0;
        double sig_st = sqrt(var_st);

        printf("%-6s %8.4f %8.1f %8.4f %6dM %7.1fs\n",
               label, avg_st, max_st, sig_st, reads_M, elapsed);
        fprintf(fout, "%-6s %8.4f %8.1f %8.4f %6dM %7.1fs\n",
                label, avg_st, max_st, sig_st, reads_M, elapsed);

        fprintf(fout, "  %-7s %4s %4s %10s %10s %7s\n", "level", "Z", "nodes", "avg_blocks", "capacity", "occ%");
        for (int li = 0; li < L; li++) {
            int lvl = li + 1;
            double occ = oram.get_occupancy(li);
            int nodes = 1 << li;
            double cap = (double)nodes * Zvec[li];
            double pct = (cap > 0) ? (occ / cap) * 100.0 : 0;
            printf("  level %2d  Z=%d  nodes=%5d  avg_blocks=%.2f  capacity=%.0f  %.1f%%\n",
                   lvl, Zvec[li], nodes, occ, cap, pct);
            fprintf(fout, "  level %2d  Z=%d  nodes=%5d  avg_blocks=%.2f  capacity=%.0f  %.1f%%\n",
                    lvl, Zvec[li], nodes, occ, cap, pct);
        }
        fflush(fout);
        fprintf(stderr, "  %s done (%.1fs)\n", label, elapsed);
    };

    run(Z3,   "Z3",   seed_base + 3);
    run(Z43,  "Z43",  seed_base + 43);
    run(Z431, "Z431", seed_base + 431);

    auto t2 = chrono::system_clock::now();
    time_t tt2 = chrono::system_clock::to_time_t(t2);
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", localtime(&tt2));
    fprintf(fout, "\n=== Finished: %s ===\n", timebuf);
    fclose(fout);
    printf("\nResults appended to %s\n", outfile);
    printf("Press any key to exit...\n");
    getchar();
    return 0;
}
