/**
 * Z431ORAM security validation: measure empirical λ^ac vs theoretical λ^th.
 * L=20, L0=8, Z: leaf=1, mid=3, top=4.
 * Warmup: 1 traversal. Measure: 2^s accesses for s=14,18,22,26.
 * Record overflow counts at R=8,16,32.
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z431_security.exe z431_security.cpp
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

class PathORAM {
public:
    int L, L0, N, num_blocks;
    double beta;
    unordered_map<int, int> stash;
    unordered_map<int, int> pos_map;
    vector<vector<pair<int,int>>> tree;
    unordered_map<int, unordered_set<int>> cand;
    mt19937_64 rng;
    uniform_int_distribution<int> leaf_dist;

    PathORAM(int L_, double beta_, uint64_t seed, int L0_ = 8)
        : L(L_), beta(beta_), L0(L0_), rng(seed) {
        N = (1 << L) - 1;
        num_blocks = max(1, (int)(N * beta));
        tree.resize(N + 1);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));
        for (int bid = 0; bid < num_blocks; bid++)
            pos_map[bid] = leaf_dist(rng);
        rebuild_cand();
        evict_all();
    }

    int get_Z(int lev) const {
        int h = L - 1 - lev;                 // height from leaf: 0=leaf
        if (h == 0) return 1;                // leaf: Z=1
        if (h < L0) return 3;                // mid L0-1: Z=3
        return 4;                            // top L-L0: Z=4
    }

    vector<int> get_path(int leaf) const {
        vector<int> path(L);
        int node = 1;
        for (int lev = 0; lev < L; lev++) {
            path[lev] = node;
            if (lev < L - 1) {
                if ((leaf >> (L - 2 - lev)) & 1) node = 2*node+1;
                else node = 2*node;
            }
        }
        return path;
    }

    void rebuild_cand() {
        cand.clear();
        for (auto& kv : stash) {
            auto p = get_path(kv.second);
            for (int node : p) cand[node].insert(kv.first);
        }
    }
    void cand_add(int bid, int leaf) {
        auto p = get_path(leaf);
        for (int node : p) cand[node].insert(bid);
    }
    void cand_remove(int bid, int leaf) {
        auto p = get_path(leaf);
        for (int node : p) {
            auto it = cand.find(node);
            if (it != cand.end()) it->second.erase(bid);
        }
    }

    void evict_all() {
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node])
                if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            tree[node].clear();
        }
        for (int lev = L-1; lev >= 0; lev--) {
            int Z_here = get_Z(lev);
            int first = 1 << lev;
            int last = min((1<<(lev+1))-1, N);
            for (int node = first; node <= last; node++) {
                auto it = cand.find(node);
                if (it == cand.end()) continue;
                int taken = 0;
                vector<int> to_evict;
                for (int bid : it->second) {
                    if (taken >= Z_here) break;
                    if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
                }
                for (int bid : to_evict) {
                    int lf = stash[bid];
                    tree[node].push_back({bid, lf});
                    stash.erase(bid);
                    cand_remove(bid, lf);
                }
            }
        }
    }

    int access(int block_id) {
        int old_lf = (block_id < num_blocks) ? pos_map[block_id] : leaf_dist(rng);
        int new_lf = leaf_dist(rng);
        if (block_id < num_blocks) pos_map[block_id] = new_lf;
        auto path = get_path(old_lf);
        for (int node : path) {
            for (auto& [bid, lf] : tree[node])
                if (!stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            tree[node].clear();
        }
        if (stash.count(block_id)) {
            int old = stash[block_id];
            auto p_old = get_path(old);
            auto p_new = get_path(new_lf);
            for (int node : p_old) {
                auto it = cand.find(node);
                if (it != cand.end()) it->second.erase(block_id);
            }
            for (int node : p_new) cand[node].insert(block_id);
            stash[block_id] = new_lf;
        } else {
            stash[block_id] = new_lf;
            cand_add(block_id, new_lf);
        }
        for (int i = (int)path.size()-1; i >= 0; i--) {
            int node = path[i], Z_here = get_Z(i);
            auto it = cand.find(node);
            if (it == cand.end()) continue;
            int taken = 0;
            vector<int> to_evict;
            for (int bid : it->second) {
                if (taken >= Z_here) break;
                if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
            }
            for (int bid : to_evict) {
                int lf = stash[bid];
                tree[node].push_back({bid, lf});
                stash.erase(bid);
                cand_remove(bid, lf);
            }
        }
        return (int)stash.size();
    }
};

int main() {
    int L = 20, L0 = 8, warm_traversals = 1;
    double beta = 1.0 / 3.0;
    uint64_t seed = 43100;
    int s_vals[] = {14, 18, 22, 26};
    int R_vals[] = {8, 16, 32};
    int nS = 4, nR = 3;

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    double alpha = 0.9513, b_val = 1.350, ln2 = log(2.0);
    long long N_est = (1LL << L) - 1;
    long long Nb = N_est / 3;

    FILE* flog = fopen("z431_security_results.txt", "w");
    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z431ORAM Security Validation — Detailed Report\n");
    fprintf(flog, "================================================================\n\n");
    fprintf(flog, "  1. CONFIGURATION\n");
    fprintf(flog, "  ----------------------------------------\n");
    fprintf(flog, "  L = %d,  L0 = %d\n", L, L0);
    fprintf(flog, "  Tree: leaf (h=0) Z=1, mid (h=1..%d) Z=3, top (h=%d..%d) Z=4\n", L0-1, L0, L-1);
    fprintf(flog, "  Levels: root(lev=0, h=%d)..leaf(lev=%d, h=0)\n", L-1, L-1);
    fprintf(flog, "  Per-level Z (root to leaf): ");
    for (int lev = 0; lev < L; lev++) {
        fprintf(flog, "%d", (lev == L-1 ? 1 : (lev >= L-L0 ? 3 : 4)));
        if ((lev+1) % 20 == 0) fprintf(flog, " ");
    }
    fprintf(flog, "\n");
    fprintf(flog, "  N_est = 2^%d - 1 = %lld\n", L, N_est);
    fprintf(flog, "  Nb = N_est / 3 = %lld  (beta = 1/3)\n", Nb);
    fprintf(flog, "  Warmup: %d full traversal (%lld reads)\n", warm_traversals, warm_traversals * Nb);
    fprintf(flog, "  Measurement: s = 14, 18, 22, 26  (2^s reads each)\n");
    fprintf(flog, "  R = 8, 16, 32  (stash overflow thresholds)\n");
    fprintf(flog, "  Seed base: %llu\n\n", (unsigned long long)seed);

    fprintf(flog, "  2. THEORETICAL PARAMETERS (Z431, second fixed point)\n");
    fprintf(flog, "  ----------------------------------------\n");
    fprintf(flog, "  zeta_4' = 0.2725\n");
    fprintf(flog, "  alpha_4' = ln(4/(1+2*zeta_4')) = 0.9513\n");
    fprintf(flog, "  b_4' = 1+2*zeta_4' + 4*ln(4/(1+2*zeta_4')) - 4 = 1.350\n");
    fprintf(flog, "  Tail bound: Pr[X > R] <= exp(-alpha*R - b) = 0.2592 * 0.3862^R\n");
    fprintf(flog, "  lambda^th(R,s) = max(0, (alpha*R + b)/ln(2) - s)\n\n");

    fprintf(flog, "  Pre-computed lambda^th:\n");
    fprintf(flog, "  %4s ", "R");
    for (int si = 0; si < nS; si++) fprintf(flog, " s=%-2d", s_vals[si]);
    fprintf(flog, "\n  ----");
    for (int si = 0; si < nS; si++) fprintf(flog, " ----");
    fprintf(flog, "\n");
    for (int ri = 0; ri < nR; ri++) {
        int R = R_vals[ri];
        fprintf(flog, "  %4d", R);
        for (int si = 0; si < nS; si++)
            fprintf(flog, " %4.0f", max(0.0, (alpha*R + b_val)/ln2 - s_vals[si]));
        fprintf(flog, "\n");
    }
    fprintf(flog, "\n");
    fprintf(flog, "  3. EXPERIMENTAL RESULTS\n");
    fprintf(flog, "  ----------------------------------------\n");
    fprintf(flog, "  %-3s %10s %8s %8s %4s %10s %7s %7s\n",
            "s", "reads", "mean", "max", "R", "overflow", "λ^th", "λ^ac");
    fprintf(flog, "  --- ---------- -------- -------- ---- ---------- ------- -------\n");
    fflush(flog);

    printf("================================================================\n");
    printf("  Z431ORAM Security  L=%d L0=%d  Nb=%lld  warmup=%d\n", L, L0, Nb, warm_traversals);
    printf("  Z: leaf=1, mid(1..%d)=3, top(%d..%d)=4\n", L0-1, L0, L-1);
    printf("================================================================\n\n");

    for (int si = 0; si < nS; si++) {
        int s = s_vals[si];
        long long total = 1LL << s;
        printf("\n--- s=%d  (2^%d = %lld accesses) ---\n", s, s, total);

        PathORAM oram(L, beta, seed + s, L0);
        printf("  Warmup %d traversal (%lld reads)...\n", warm_traversals, (long long)warm_traversals * Nb);
        fflush(stdout);
        auto t0 = chrono::steady_clock::now();
        for (int r = 0; r < warm_traversals; r++)
            for (int bid = 0; bid < Nb; bid++)
                oram.access(bid);
        auto t1 = chrono::steady_clock::now();
        double w_sec = chrono::duration<double>(t1-t0).count();
        printf("  Warmup done (%.0fs)\n", w_sec);

        t0 = chrono::steady_clock::now();
        int overflow[3] = {0, 0, 0};
        double sum = 0, mx = 0;
        long long REPORT = max(1LL, total / 10);  // 10 checkpoints

        for (long long i = 0; i < total; i++) {
            int st = oram.access(i % Nb);
            sum += st; if (st > mx) mx = st;
            for (int ri = 0; ri < nR; ri++)
                if (st > R_vals[ri]) overflow[ri]++;

            if (i > 0 && i % REPORT == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2-t0).count();
                double remain = (total-i) / (i/el);
                int rh = (int)(remain/3600), rm = (int)((remain-rh*3600)/60);
                printf("\r  [%lld/%lld] mean=%.4f max=%.0f %4.0fs ETA %dh%02dm",
                       i, total, sum/i, mx, el, rh, rm);
                fflush(stdout);
            }
        }
        auto t2 = chrono::steady_clock::now();
        double el = chrono::duration<double>(t2-t0).count();
        double avg = sum / total;

        printf("\r  s=%-2d  mean=%.4f  max=%.0f  time=%.0fs\n", s, avg, mx, el);

        for (int ri = 0; ri < nR; ri++) {
            int R = R_vals[ri], ov = overflow[ri];
            double lam_th = max(0.0, (alpha*R + b_val)/ln2 - s);
            double lam_ac = (ov > 0) ? -log2((double)ov / total) : INFINITY;

            fprintf(flog, "  %-3d %10lld %8.4f %8.0f %4d %5d/%-6lld %6.0f",
                    s, total, avg, mx, R, ov, total, lam_th);
            if (ov > 0) fprintf(flog, " %6.1f\n", lam_ac);
            else fprintf(flog, " %6s\n", "inf");

            const char* lac_str = (ov > 0) ? to_string((int)lam_ac).c_str() : "inf";
            printf("    R=%-2d  overflow=%d/%lld  lam^th=%.0f  lam^ac=%s\n",
                   R, ov, total, lam_th, lac_str);
            fflush(flog);
        }
        fflush(flog);
    }

    now = chrono::system_clock::now(); tt = chrono::system_clock::to_time_t(now);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    fprintf(flog, "\n  Finished: %s\n", tbuf); fclose(flog);
    printf("\n=== Done. Log: z431_security_results.txt ===\n");
    return 0;
}
