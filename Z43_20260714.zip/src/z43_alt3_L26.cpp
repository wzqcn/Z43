#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

vector<int> make_Z_alt3(int L) {
    vector<int> Z(L);
    for (int li = 0; li < L; li++) {
        int h = L - 1 - li;
        if (h < 8) Z[li] = 3;
        else { int t = (h - 8) % 4; Z[li] = (t <= 2) ? 4 : 3; } // 4,4,4,3
    }
    return Z;
}

class ZORAM {
public:
    int L, N, Nb;
    vector<int> Z_per_level;
    unordered_map<int, int> stash, stash_data;
    vector<int> pos_map;
    vector<vector<pair<int,int>>> tree;
    unordered_map<int, unordered_set<int>> cand;
    mt19937_64 rng;
    uniform_int_distribution<int> leaf_dist;

    ZORAM(int L_, const vector<int>& Zvec, uint64_t seed) : L(L_), Z_per_level(Zvec), rng(seed) {
        N = (1 << L) - 1; Nb = max(1, (int)(N * (1.0/3)));
        tree.resize(N + 1); pos_map.resize(Nb);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));
        for (int bid = 0; bid < Nb; bid++) {
            int leaf = leaf_dist(rng);
            pos_map[bid] = leaf; stash[bid] = leaf; stash_data[bid] = bid;
        }
        for (auto& kv : stash) for (int n : get_path(kv.second)) cand[n].insert(kv.first);
        evict_all();
    }

    vector<int> get_path(int leaf) const {
        vector<int> p(L); int node = 1;
        for (int lev = 0; lev < L; lev++) { p[lev] = node; if (lev < L-1) node = 2*node+((leaf>>(L-2-lev))&1); }
        return p;
    }

    void evict_all() {
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node]) if (bid>=0 && !stash.count(bid)) { stash[bid]=lf; cand_add(bid,lf); }
            tree[node].clear();
        }
        for (int li = L-1; li >= 0; li--) {
            int first = 1<<li, last = min((1<<(li+1))-1, N), Zn = Z_per_level[li];
            for (int node = first; node <= last; node++) {
                int taken=0; vector<int> to_evict;
                for (int b: cand[node]) { if (taken>=Zn) break; if (stash.count(b)) { to_evict.push_back(b); taken++; } }
                for (int b: to_evict) { int lf=stash[b]; tree[node].push_back({b,lf}); stash.erase(b); cand_remove(b,lf); }
                while ((int)tree[node].size()<Zn) tree[node].push_back({-1,-1});
            }
        }
    }

    void cand_add(int bid, int leaf) { for (int n: get_path(leaf)) cand[n].insert(bid); }
    void cand_remove(int bid, int leaf) { for (int n: get_path(leaf)) cand[n].erase(bid); }

    int access(int bid) {
        int old_leaf = (bid<Nb) ? pos_map[bid] : leaf_dist(rng);
        int new_leaf = leaf_dist(rng);
        if (bid<Nb) pos_map[bid] = new_leaf;
        auto path = get_path(old_leaf);
        for (int li=0; li<L; li++) { int node=path[li]; for (auto& [b,lf]: tree[node]) if (b>=0&&!stash.count(b)){stash[b]=lf;cand_add(b,lf);} tree[node].clear(); }
        if (stash_data.count(bid)) { int ol=stash[bid]; for (int n:get_path(ol)) cand[n].erase(bid); stash[bid]=new_leaf; for (int n:get_path(new_leaf)) cand[n].insert(bid); }
        else { stash[bid]=new_leaf; stash_data[bid]=bid; cand_add(bid,new_leaf); }
        for (int i=L-1; i>=0; i--) {
            int node=path[i], Zn=Z_per_level[i]; int taken=0; vector<int> to_evict;
            for (int b: cand[node]) { if (taken>=Zn) break; if (stash.count(b)) { to_evict.push_back(b); taken++; } }
            for (int b: to_evict) { int lf=stash[b]; tree[node].push_back({b,lf}); stash.erase(b); cand_remove(b,lf); }
            while ((int)tree[node].size()<Zn) tree[node].push_back({-1,-1});
        }
        return (int)stash.size();
    }
};

int main() {
    int L = 26, warm_rd = 1;
    long long total = 50000000LL;

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    vector<int> Zvec = make_Z_alt3(L);
    printf("================================================================\n");
    printf("  Z43 Alt3 L=%d  50M reads  warmup=%d\n", L, warm_rd);
    printf("  alt3: bottom 8 Z=3, then [4,4,4,3] alternating\n");
    printf("  Z: "); for (int li=0; li<L; li++) printf("%d",Zvec[li]);
    printf("\n  Started: %s\n", tbuf);
    printf("================================================================\n\n");
    fflush(stdout);

    FILE* flog = fopen("z43_alt3_L26_50M.txt", "w");
    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z43 Alt3 L=%d  50M reads  warmup=%d\n", L, warm_rd);
    fprintf(flog, "  Z: "); for (int li=0; li<L; li++) fprintf(flog, "%d",Zvec[li]);
    fprintf(flog, "\n  Started: %s\n", tbuf);
    fprintf(flog, "================================================================\n\n");
    fprintf(flog, "%12s %10s %10s %10s %8s %8s\n", "reads", "avg", "sigma", "max", "cycles", "time");
    fflush(flog);

    ZORAM oram(L, Zvec, (uint64_t)L*100 + 303);
    printf("Nb=%d  N=%d  evict_all...\n", oram.Nb, oram.N); fflush(stdout);

    printf("Warmup %d round (%d accesses)...\n", warm_rd, warm_rd * oram.Nb);
    for (int r=0; r<warm_rd; r++) {
        for (int bid=0; bid<oram.Nb; bid++) oram.access(bid);
        printf("  round %d/%d done\n", r+1, warm_rd);
    }

    auto t0 = chrono::steady_clock::now();
    double sum=0, sumsq=0, mx=0, mn=1e9;
    long long REPORT = max(1LL, total/200);
    for (long long i=0; i<total; i++) {
        int st = oram.access(i%oram.Nb);
        sum+=st; sumsq+=(double)st*st; if (st>mx) mx=st; if (st<mn) mn=st;
        if (i>0 && i%REPORT==0) {
            auto t2=chrono::steady_clock::now();
            double el=chrono::duration<double>(t2-t0).count();
            double remain=(total-i)/(i/el);
            int rh=(int)(remain/3600), rm=(int)((remain-rh*3600)/60);
            double avg=sum/i, var=sumsq/i-avg*avg; if (var<0) var=0;
            fprintf(flog, "%12lld %10.4f %10.4f %10.0f %7.1f %7.0fs\n", i, avg, sqrt(var), mx, (double)i/oram.Nb, el);
            printf("  [%lld/50M] avg=%.4f sig=%.4f max=%.0f ETA %dh%02dm\n", i/1000000, avg, sqrt(var), mx, rh, rm);
        }
    }
    auto t2=chrono::steady_clock::now();
    double el=chrono::duration<double>(t2-t0).count();
    double avg=sum/total, var=sumsq/total-avg*avg; if (var<0) var=0;
    double sig=sqrt(var);

    printf("\n=== Final: avg=%.4f sigma=%.4f max=%.0f min=%.0f time=%.0fs ===\n", avg, sig, mx, mn, el);
    fprintf(flog, "\n=== Final: avg=%.4f sigma=%.4f max=%.0f min=%.0f ===\n", avg, sig, mx, mn);
    fclose(flog);
    printf("Log: z43_alt3_L26_50M.txt\n");
    return 0;
}
