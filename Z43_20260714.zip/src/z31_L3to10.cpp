/**
 * Z31ORAM: bottom L0_z1 levels Z=1, upper levels Z=3.
 * L=3..10, 4M reads each — baseline for Z431.
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z31_L3to10.exe z31_L3to10.cpp
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

using ull = unsigned long long;
struct Block { ull leaf; int data; };

vector<int> make_Z31(int L, int L0_z1) {
    vector<int> Z(L);
    for (int li = 0; li < L; li++) {
        int h = L - 1 - li;
        Z[li] = (h < L0_z1) ? 1 : 3;
    }
    return Z;
}

mt19937_64 rng;
uniform_int_distribution<ull> leaf_dist;

vector<ull> get_path(ull leaf, int L) {
    vector<ull> p(L); ull node = 1;
    for (int lev = 0; lev < L; lev++) { p[lev] = node; if (lev < L-1) node = 2ULL*node + ((leaf>>(L-2-lev))&1); }
    return p;
}

int main() {
    int L0_z1 = 1;                 // bottom 1 level (leaf) Z=1, rest Z=3
    int Nb_max = 20000;            // cap blocks per L at 20K
    long long total = 4000000LL;   // 4M reads

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    FILE* flog = fopen("z31_L3to10.txt", "w");
    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z31ORAM: bottom L0_z1=%d  Z=1, upper Z=3  L=3..10  4M reads\n", L0_z1);
    fprintf(flog, "  Blocks capped at %d\n", Nb_max);
    fprintf(flog, "  Started: %s\n", tbuf);
    fprintf(flog, "================================================================\n\n");
    fprintf(flog, "%-4s %4s %12s %6s %10s %10s %10s %8s %8s\n",
            "L", "Zpat", "N_est", "blk", "avg", "sigma", "max", "cycles", "time");
    fflush(flog);

    printf("================================================================\n");
    printf("  Z31ORAM: bottom %d Z=1, upper Z=3  L=3..10  4M reads\n", L0_z1);
    printf("  Started: %s\n", tbuf);
    printf("================================================================\n\n");

    FILE* fdetail = fopen("z31_L3to10_detail.txt", "w");
    fprintf(fdetail, "L,progress,bid_range,avg,sigma,max,elapsed,stash\n");

    for (int L = 3; L <= 10; L++) {
        vector<int> Zvec = make_Z31(L, L0_z1);
        ull N_est = (1ULL << L) - 1;
        int Nb_blocks = (int)min((ull)Nb_max, N_est);

        char zpat[16] = {0};
        for (int li = 0; li < L && li < 15; li++) zpat[li] = '0' + Zvec[li];

        printf("\n--- L=%d  N_est=%llu  Nb_blocks=%d ---\n", L, N_est, Nb_blocks);
        printf("  Z: ");
        for (int li = 0; li < L; li++) printf("%d", Zvec[li]);
        printf("\n"); fflush(stdout);

        fprintf(flog, "\n--- L=%d  N_est=%llu  blocks=%d  Z: %s ---\n", L, N_est, Nb_blocks, zpat);
        fflush(flog);

        rng.seed((uint64_t)L * 31 + 100);
        int leaf_bits = min(L-1, 30);
        leaf_dist = uniform_int_distribution<ull>(1, 1ULL << leaf_bits);

        unordered_map<int, ull> pos_map;
        unordered_map<int, Block> stash;
        unordered_map<ull, vector<pair<int,ull>>> tree;

        printf("  Warmup (%d writes)...\n", Nb_blocks); fflush(stdout);
        auto t0 = chrono::steady_clock::now();

        for (int bid = 0; bid < Nb_blocks; bid++) {
            ull leaf = leaf_dist(rng);
            pos_map[bid] = leaf;
            auto path = get_path(leaf, L);

            for (int li = 0; li < L; li++) {
                ull node = path[li];
                auto it = tree.find(node);
                if (it != tree.end()) {
                    for (auto& [b, lf] : (*it).second)
                        if (b >= 0 && !stash.count(b)) stash[b] = {lf, b};
                    tree.erase(node);
                }
            }
            stash[bid] = {leaf, bid};

            unordered_map<int, vector<ull>> st_path;
            for (auto& [b, blk] : stash) st_path[b] = get_path(blk.leaf, L);
            for (int i = L-1; i >= 0; i--) {
                ull nd = path[i]; int Zn = Zvec[i];
                int taken = 0; vector<int> to_evict;
                for (auto& [b, blk] : stash) {
                    if (taken >= Zn) break;
                    if (st_path[b][i] == nd) { to_evict.push_back(b); taken++; }
                }
                if (!tree.count(nd)) tree[nd] = {};
                for (int b : to_evict) { ull lf = stash[b].leaf; tree[nd].push_back({b,lf}); stash.erase(b); st_path.erase(b); }
                while ((int)tree[nd].size() < Zn) tree[nd].push_back({-1,0ULL});
            }

            if (bid % 20000 == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2-t0).count();
                printf("\r  warmup %d/%d stash=%zu tree=%zu %.0fs",
                       bid, Nb_blocks, stash.size(), tree.size(), el);
                fflush(stdout);
            }
        }
        auto t1 = chrono::steady_clock::now();
        double w_el = chrono::duration<double>(t1-t0).count();
        printf("\r  Warmup done (%.0fs) stash=%zu tree=%zu\n", w_el, stash.size(), tree.size());

        // Measurement
        t0 = chrono::steady_clock::now();
        double sum = 0, sumsq = 0, mx = 0, mn = 1e9;
        long long REPORT = max(1LL, total / 50);
        long long LOG_DETAIL = max(1LL, total / 20); // log 20 checkpoints to detail file

        for (long long i = 0; i < total; i++) {
            int bid = i % Nb_blocks;
            ull old_leaf = pos_map.count(bid) ? pos_map[bid] : leaf_dist(rng);
            ull new_leaf = leaf_dist(rng);
            pos_map[bid] = new_leaf;
            auto path = get_path(old_leaf, L);

            for (int li = 0; li < L; li++) {
                ull node = path[li];
                auto it = tree.find(node);
                if (it != tree.end()) {
                    for (auto& [b, lf] : (*it).second)
                        if (b >= 0 && !stash.count(b)) stash[b] = {lf, b};
                    tree.erase(node);
                }
            }
            if (stash.count(bid)) { stash[bid].leaf = new_leaf; }
            else stash[bid] = {new_leaf, bid};

            unordered_map<int, vector<ull>> st_path;
            for (auto& [b, blk] : stash) st_path[b] = get_path(blk.leaf, L);

            for (int i2 = L-1; i2 >= 0; i2--) {
                ull nd = path[i2]; int Zn = Zvec[i2];
                int taken = 0; vector<int> to_evict;
                for (auto& [b, blk] : stash) {
                    if (taken >= Zn) break;
                    if (st_path[b][i2] == nd) { to_evict.push_back(b); taken++; }
                }
                if (!tree.count(nd)) tree[nd] = {};
                for (int b : to_evict) { ull lf = stash[b].leaf; tree[nd].push_back({b,lf}); stash.erase(b); st_path.erase(b); }
                while ((int)tree[nd].size() < Zn) tree[nd].push_back({-1,0ULL});
            }

            int st = (int)stash.size();
            sum += st; sumsq += (double)st * st;
            if (st > mx) mx = st; if (st < mn) mn = st;

            if (i > 0 && i % REPORT == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2-t0).count();
                double remain = (total-i) / (i/el);
                int rh = (int)(remain/3600), rm = (int)((remain-rh*3600)/60);
                double avg = sum/i, var = sumsq/i-avg*avg;
                if (var < 0) var = 0;
                printf("\r  [%lld/4M] avg=%.4f sig=%.4f max=%.0f %4.0fs ETA %dh%02dm stash=%zu",
                       i/100000, avg, sqrt(var), mx, el, rh, rm, stash.size());
                fflush(stdout);
            }
            if (i > 0 && i % LOG_DETAIL == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2-t0).count();
                double avg = sum/i, var = sumsq/i-avg*avg;
                if (var < 0) var = 0;
                fprintf(fdetail, "%d,%lld,%d,%.4f,%.4f,%.0f,%.1f,%zu\n",
                        L, i/100000, Nb_blocks, avg, sqrt(var), mx, el, stash.size());
                fflush(fdetail);
                fprintf(flog, "  [%lld/4M] avg=%.4f sig=%.4f max=%.0f stash=%zu\n",
                        i/100000, avg, sqrt(var), mx, stash.size());
                fflush(flog);
            }
        }
        auto t2 = chrono::steady_clock::now();
        double el = chrono::duration<double>(t2-t0).count();
        double avg = sum/total, var = sumsq/total - avg*avg;
        if (var < 0) var = 0; double sig = sqrt(var), cycles = (double)total/Nb_blocks;

        printf("\r  %-4d %4s %12llu %6d %10.4f %10.4f %10.0f %7.1f %7.0fs\n",
               L, zpat, N_est, Nb_blocks, avg, sig, mx, cycles, el);
        fprintf(flog, "%-4d %4s %12llu %6d %10.4f %10.4f %10.0f %7.1f %7.0fs\n",
                L, zpat, N_est, Nb_blocks, avg, sig, mx, cycles, el);
        fflush(flog);
    }

    now = chrono::system_clock::now(); tt = chrono::system_clock::to_time_t(now);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    fprintf(flog, "\n=== Finished: %s ===\n", tbuf);
    fprintf(fdetail, "\n=== Finished: %s ===\n", tbuf);
    fclose(flog); fclose(fdetail);
    printf("\n=== Done. Logs: z31_L3to10.txt, z31_L3to10_detail.txt ===\n");
    return 0;
}
