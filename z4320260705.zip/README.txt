================================================================================
  Z43ORAM — Experiment Suite (2026-07-05)
================================================================================

Directory: publish/20260705/

This package contains the complete experiment source code, figure generation
scripts, and build files for the Z43ORAM paper.

================================================================================
1. EXPERIMENT PROGRAMS (RUN3 Series)
================================================================================

All experiment programs use the RUN3 methodology:
  - Warmup: 1 round (cyclic read of all N blocks)
  - Measurement: fixed number of cyclic reads (worst-case access pattern)
  - Z configuration per-level, dummy padding to Z for privacy
  - Standard Path ORAM access(operation, address, data) interface

Files:
  z2_run3.cpp   -- Z=2, beta=1/2, 4M reads
  z3_run3.cpp   -- Z=3, beta=1/3, 4M reads
  z4_run3.cpp   -- Z=4, beta=1/3, 4M reads
  z5_run3.cpp   -- Z=5, beta=1/3, 4M reads
  z43_run3.cpp  -- Z43ORAM, L0 configurable, 4M reads
  occ.cpp       -- Per-level occupancy, L=18, 50M reads,
                   Z3 / Z43(L0=8) / Z431(L0=8)

Compile (require MSVC 2022 Community; auto-detected from default install path):
  compile_z2_3.bat  ->  z2_run3.exe
  compile_z3_3.bat  ->  z3_run3.exe
  compile_z4_3.bat  ->  z4_run3.exe
  compile_z5_3.bat  ->  z5_run3.exe
  compile_z43_3.bat ->  z43_run3.exe
  occ.bat           ->  occ.exe

Usage:
  z3_run3.exe [total_reads] [warmup_rounds]
    default: 100000 reads, 200 warmup rounds
    recommended: z3_run3.exe 4000000 1  (4M reads, 1 warmup round)

  z43_run3.exe [total_reads] [warmup_rounds] [L0]
    default: 100000 reads, 200 warmup, L0=8
    recommended: z43_run3.exe 4000000 1 8  (4M, 1 round, L0=8)

  occ.exe [L] [total_reads_millions] [warmup_rounds]
    default: L=18, 50M reads, 1 warmup round
    recommended: occ.exe 18 50 1

Batch tests (compile + run multiple configs):
  Z43ORAML891011.BAT  -- Z43ORAM L0=8,9,10,11, L=8..20, 4M reads each

================================================================================
2. FIGURE GENERATION
================================================================================

Python scripts (require Python 3, matplotlib, numpy):

  gen_all_figures.py  -- Generates 7 figures:
    fig1_stash_z2z3.pdf          Z=2,3 stash vs L
    fig4_stash_z43.pdf           Z43ORAM stash
    fig5_bandwidth_z43.pdf       Bandwidth comparison
    fig6_z3_z43_stash.pdf        Z=3 vs Z43ORAM
    fig7_z3_stash_detail.pdf     Z=3 stash detail (mu, mu+3sigma, max)
    fig9_z3_predicted_vs_actual.pdf  Z=3 predicted vs actual

  gen_fig9.py  -- Standalone fig9 generator (L1=17, eta_1=2.61)

  plot_occupancy.py  -- Per-level occupancy plots:
    fig10_z3_occupancy.pdf
    fig11_z43_occupancy.pdf
    fig12_z431_occupancy.pdf
    fig_occupancy_combined.pdf
    Input: occ_L18_results.txt

Run:
  python gen_all_figures.py
  python gen_fig9.py
  python plot_occupancy.py exp_z43/occ_L18_results.txt

================================================================================
3. DATA FILES (exp_z43/)
================================================================================

  z3_4m.txt             -- Z=3, 4M reads, L=3..22
  z3_run3_40M_results.txt -- Z=3, 4M reads, L=3..22 (full stats)
  z2_run3_results.txt   -- Z=2, 4M reads, L=3..22
  z4_run3_40M_results.txt -- Z=4, 4M reads
  z5_run3_40M_results.txt -- Z=5, 4M reads
  z43_L0=8_results.txt  -- Z43ORAM L0=8, 4M reads, L=8..20
  z43_L0=9_results.txt  -- Z43ORAM L0=9
  z43_L0=10_results.txt -- Z43ORAM L0=10
  z43_L0=11_results.txt -- Z43ORAM L0=11
  occ_L18_results.txt   -- Per-level occupancy, 50M reads

  test_oram.cpp / test_oram.bat -- ORAM correctness test (write/read verify)

================================================================================
4. KEY PARAMETERS
================================================================================

  L0 = 8   (critical height for Z=3: E_8 <= zeta_4, E_9 > zeta_4)
  L1* = 17 (first L with E >= 2, empirical)
  eta_1 = 2.61, sigma_1 = 4.18 (at L=17)

  Fixed points:
    zeta_4  = 0.1386 (Z=4, first)
    zeta_4' = 0.2725 (Z=4, second)
    zeta_5  = 0.0121 (Z=5)

================================================================================

================================================================================
5. VISUAL STUDIO SOLUTION
================================================================================

  Z43ORAM.sln  --  Contains all 6 projects
    occ.vcxproj       occ.cpp
    z2_run3.vcxproj   z2_run3.cpp
    z3_run3.vcxproj   z3_run3.cpp
    z4_run3.vcxproj   z4_run3.cpp
    z5_run3.vcxproj   z5_run3.cpp
    z43_run3.vcxproj  z43_run3.cpp

  Open Z43ORAM.sln in VS 2022, select Release/x64, Build All.
  C++20 standard, /O2 optimization enabled.
