@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo MSVC environment setup failed!
    exit /b 1
)
cd /d "%~dp0"
echo Compiling z2_run3.cpp...
cl /O2 /std:c++20 /EHsc /nologo /Fe:z2_run3.exe z2_run3.cpp 2>&1
if %ERRORLEVEL% EQU 0 (
    echo ====== Compilation SUCCESS ======
) else (
    echo ====== Compilation FAILED ======
)
