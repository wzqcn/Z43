@echo off
if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cd /d "%~dp0"
cl /O2 /std:c++20 /EHsc /nologo /Fe:z43_L12_L26.exe z43_L12_L26.cpp
if %ERRORLEVEL% equ 0 (echo Build OK. Run: z43_L12_L26.exe) else (echo Build FAILED)
pause
