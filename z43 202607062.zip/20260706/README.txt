================================================================================
  Z43ORAM — Experiment Suite (2026-07-06)
================================================================================

Directory: publish/20260706/

This package contains the complete experiment source code, figure generation
scripts, build files, and test tools for the Z43ORAM paper.

================================================================================
1. EXPERIMENT PROGRAMS (RUN3 Series)
================================================================================

All use the RUN3 methodology: warmup=1 round, cyclic worst-case reads.

  occ.cpp           -- Per-level occupancy, L=18, 50M reads
  z2_run3.cpp       -- Z=2, 4M reads
  z3_run3.cpp       -- Z=3, 4M reads
  z4_run3.cpp       -- Z=4, 4M reads
  z5_run3.cpp       -- Z=5, 4M reads
  z43_run3.cpp      -- Z43ORAM, L0 configurable, 4M reads

Compile:
  compile_z2_3.bat  -> z2_run3.exe
  compile_z3_3.bat  -> z3_run3.exe
  compile_z4_3.bat  -> z4_run3.exe
  compile_z5_3.bat  -> z5_run3.exe
  compile_z43_3.bat -> z43_run3.exe
  occ.bat           -> occ.exe

================================================================================
2. TEST & CONVERGENCE TOOLS
================================================================================

  z3_test.cpp       -- Interactive Z3 stash tester (L, reads_M configurable)
  z3_conv20.cpp     -- Z3 L=20 convergence test (run until sigma/avg < target)
  z43_highL0.cpp    -- Z43ORAM L0=12..17, L=L0..22, 4M reads each
  z43_L11_L26.cpp   -- Z43ORAM L0=11, L=26, 50M reads (convergence check)
  z43_L12_L26.cpp   -- Z43ORAM L0=12, L=26, 50M reads (divergence check)

Compile:
  compile_z3_test.bat       -> z3_test.exe
  compile_z43_highL0.bat    -> z43_highL0.exe
  compile_z43_L11_L26.bat   -> z43_L11_L26.exe
  compile_z43_L12_L26.bat   -> z43_L12_L26.exe

================================================================================
3. VISUAL STUDIO SOLUTION
================================================================================

  Z43ORAM.sln  -- Contains all projects (Open in VS 2022, Release/x64)
    occ.vcxproj       z2_run3.vcxproj   z3_run3.vcxproj
    z4_run3.vcxproj   z5_run3.vcxproj   z43_run3.vcxproj

================================================================================
4. KEY PARAMETERS
================================================================================

  L0 = 8    (critical height: E8 <= zeta4=0.1386, E9 > zeta4)
  L1* = 17  (first L with E >= 2)
  eta_1 = 2.61, sigma_1 = 4.18 (at L=17)

  Z43ORAM convergent range: L0=8,9,10,11
  Z43ORAM divergent:        L0=12 (L=26 avg stash ~3.6)
  Z3 at L=26:               avg 820.16 (sigma 91.08)

================================================================================
