/**
 * Z43ORAM High-L0 Test: L0=12..17, L=L0..22, 4M reads each.
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z43_highL0.exe z43_highL0.cpp
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

int L_max = 22, L0_val;
double loadf = 1.0 / 3;
long long total_reads = 4000000LL;
int warm_rd = 1;

unordered_map<int, int> stash, stash_data;
vector<int> pos_map;
vector<vector<pair<int,int>>> tree;
unordered_map<int, unordered_set<int>> cand;
vector<int> Z_per_level;
mt19937_64 rng;
uniform_int_distribution<int> leaf_dist;

void build_Z(int L, int L0) {
    Z_per_level.resize(L);
    for (int li = 0; li < L; li++) {
        int h = L - 1 - li;
        Z_per_level[li] = (h < L0) ? 3 : 4;
    }
}

vector<int> get_path(int leaf, int L) {
    vector<int> p(L);
    int node = 1;
    for (int lev = 0; lev < L; lev++) {
        p[lev] = node;
        if (lev < L - 1) node = 2 * node + ((leaf >> (L - 2 - lev)) & 1);
    }
    return p;
}
void cand_add(int bid, int leaf, int L) { for (int n : get_path(leaf, L)) cand[n].insert(bid); }
void cand_remove(int bid, int leaf, int L) { for (int n : get_path(leaf, L)) cand[n].erase(bid); }
void cand_update(int bid, int o, int n, int L) { cand_remove(bid, o, L); cand_add(bid, n, L); }

int access(int L, int bid) {
    int Nb = max(1, (int)(((1 << L) - 1) * loadf));
    int old_leaf = (bid < (int)pos_map.size()) ? pos_map[bid] : leaf_dist(rng);
    int new_leaf = leaf_dist(rng);
    if (bid < (int)pos_map.size()) pos_map[bid] = new_leaf;
    auto path = get_path(old_leaf, L);
    for (int li = 0; li < L; li++) {
        int node = path[li];
        for (auto& [b, lf] : tree[node])
            if (b >= 0 && !stash.count(b)) { stash[b] = lf; cand_add(b, lf, L); }
        tree[node].clear();
    }
    if (stash_data.count(bid)) {
        cand_update(bid, stash[bid], new_leaf, L);
        stash[bid] = new_leaf;
    } else {
        stash[bid] = new_leaf; stash_data[bid] = bid;
        cand_add(bid, new_leaf, L);
    }
    for (int i = L - 1; i >= 0; i--) {
        int node = path[i], lev = i, Zn = Z_per_level[lev];
        int taken = 0; vector<int> to_evict;
        for (int b : cand[node]) {
            if (taken >= Zn) break;
            if (stash.count(b)) { to_evict.push_back(b); taken++; }
        }
        for (int b : to_evict) {
            int lf = stash[b];
            tree[node].push_back({b, lf});
            stash.erase(b); cand_remove(b, lf, L);
        }
        while ((int)tree[node].size() < Zn) tree[node].push_back({-1, -1});
    }
    return (int)stash.size();
}

void run_L0(int L0) {
    L0_val = L0;
    char logfile[256];
    sprintf(logfile, "z43_L0=%d_4M.txt", L0);
    FILE* flog = fopen(logfile, "w");

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z43ORAM  L0=%d  L=%d..%d  4M reads each  warmup=%d\n", L0, L0, L_max, warm_rd);
    fprintf(flog, "  Ztop=4  Zbot=3  load=1/3  cyclic worst-case\n");
    fprintf(flog, "  Started: %s\n", tbuf);
    fprintf(flog, "================================================================\n\n");
    fprintf(flog, "%-4s %8s %10s %10s %10s %8s %8s\n", "L", "blocks", "avg", "sigma", "max", "cycles", "time");
    fflush(flog);

    printf("\n================================================================\n");
    printf("  Z43ORAM  L0=%d  L=%d..%d  4M reads  warmup=%d\n", L0, L0, L_max, warm_rd);
    printf("================================================================\n");
    printf("%-4s %8s %10s %10s %10s %8s %8s\n", "L", "blocks", "avg", "sigma", "max", "cycles", "time");
    printf("---- -------- ---------- ---------- ---------- -------- --------\n");
    fflush(stdout);

    for (int L = L0; L <= L_max; L++) {
        int N = (1 << L) - 1;
        int Nb = max(1, (int)(N * loadf));
        build_Z(L, L0);
        tree.clear(); tree.resize(N + 1);
        stash.clear(); stash_data.clear(); cand.clear();
        pos_map.assign(Nb, 0);
        rng.seed((uint64_t)L * 100 + L0);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));

        for (int bid = 0; bid < Nb; bid++) {
            int leaf = leaf_dist(rng);
            pos_map[bid] = leaf; stash[bid] = leaf; stash_data[bid] = bid;
        }
        for (auto& kv : stash) for (int n : get_path(kv.second, L)) cand[n].insert(kv.first);

        printf("  L=%d L0=%d  Nb=%d  initializing evict_all over %d nodes...\n", L, L0, Nb, N);
        fflush(stdout);
        // Simple evict_all
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node])
                if (bid >= 0 && !stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf, L); }
            tree[node].clear();
        }
        for (int li = L - 1; li >= 0; li--) {
            int first = 1 << li, last = min((1 << (li + 1)) - 1, N), Zn = Z_per_level[li];
            for (int node = first; node <= last; node++) {
                int taken = 0; vector<int> to_evict;
                for (int b : cand[node]) { if (taken >= Zn) break; if (stash.count(b)) { to_evict.push_back(b); taken++; } }
                for (int b : to_evict) { int lf = stash[b]; tree[node].push_back({b, lf}); stash.erase(b); cand_remove(b, lf, L); }
                while ((int)tree[node].size() < Zn) tree[node].push_back({-1, -1});
            }
        }
        printf("  Init done. stash=%zu\n", stash.size());

        // Warmup
        auto t0 = chrono::steady_clock::now();
        printf("  Warmup %d round(s) (%d accesses)...\n", warm_rd, warm_rd * Nb);
        for (int r = 0; r < warm_rd; r++) {
            for (int bid = 0; bid < Nb; bid++) access(L, bid);
            printf("    round %d/%d done\n", r+1, warm_rd);
        }
        auto t1 = chrono::steady_clock::now();
        printf("  Warmup done (%.0fs)\n", chrono::duration<double>(t1 - t0).count());

        // Measurement
        t0 = chrono::steady_clock::now();
        double sum = 0, sumsq = 0, mx = 0, mn = 1e9;
        long long REPORT = max(1LL, total_reads / 100);
        for (long long i = 0; i < total_reads; i++) {
            int st = access(L, i % Nb);
            sum += st; sumsq += (double)st * st;
            if (st > mx) mx = st; if (st < mn) mn = st;
            if (i > 0 && i % REPORT == 0) {
                auto t2 = chrono::steady_clock::now();
                double el = chrono::duration<double>(t2 - t0).count();
                double rate = i / el, remain = (total_reads - i) / rate;
                int rh = (int)(remain / 3600), rm = (int)((remain - rh*3600) / 60);
                double avg = sum / i, var = sumsq / i - avg * avg;
                if (var < 0) var = 0; double sig = sqrt(var);
                printf("    [%lld/%lldM] avg=%.4f sig=%.4f max=%.0f ETA %dh%02dm\n",
                       i/1000000, total_reads/1000000, avg, sig, mx, rh, rm);
            }
        }
        auto t2 = chrono::steady_clock::now();
        double el = chrono::duration<double>(t2 - t0).count();
        double avg = sum / total_reads, var = sumsq / total_reads - avg * avg;
        if (var < 0) var = 0; double sig = sqrt(var);
        double cycles = (double)total_reads / Nb;

        printf("  %-4d %8d %10.4f %10.4f %10.0f %7.1f %7.0fs\n", L, Nb, avg, sig, mx, cycles, el);
        fprintf(flog, "%-4d %8d %10.4f %10.4f %10.0f %7.1f %7.0fs\n", L, Nb, avg, sig, mx, cycles, el);
        fflush(flog);
    }

    now = chrono::system_clock::now();
    tt = chrono::system_clock::to_time_t(now);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    fprintf(flog, "\n=== L0=%d Done: %s ===\n", L0, tbuf);
    fclose(flog);
    printf("\n=== L0=%d Done. Log: %s ===\n", L0, logfile);
}

int main() {
    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64];
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    printf("================================================================\n");
    printf("  Z43ORAM High-L0 Test Suite\n");
    printf("  L0 = 12,13,14,15,16,17  L = L0..22  4M reads each\n");
    printf("  Started: %s\n", tbuf);
    printf("================================================================\n\n");

    for (int L0 = 12; L0 <= 17; L0++) {
        printf("\n############################################################\n");
        printf("###  L0 = %d\n", L0);
        printf("############################################################\n");
        run_L0(L0);
    }

    now = chrono::system_clock::now();
    tt = chrono::system_clock::to_time_t(now);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    printf("\n================================================================\n");
    printf("  ALL DONE. Finished: %s\n", tbuf);
    printf("  Output files: z43_L0=12_4M.txt ~ z43_L0=17_4M.txt\n");
    printf("================================================================\n");
    return 0;
}
