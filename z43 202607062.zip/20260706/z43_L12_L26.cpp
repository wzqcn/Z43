/**
 * Z43ORAM L0=12, L=23, 50M reads — divergence test
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z43_L11_L23.exe z43_L11_L23.cpp
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

int L = 26, L0 = 12, Ztop = 4, Zbot = 3;
double loadf = 1.0 / 3;
int N = (1 << L) - 1;
int Nb = max(1, (int)(N * loadf));

vector<int> Z_per_level;

unordered_map<int, int> stash, stash_data;
vector<int> pos_map;
vector<vector<pair<int,int>>> tree;
unordered_map<int, unordered_set<int>> cand;
mt19937_64 rng(42);
uniform_int_distribution<int> leaf_dist(1, 1 << (L - 1));

vector<int> get_path(int leaf) {
    vector<int> p(L);
    int node = 1;
    for (int lev = 0; lev < L; lev++) {
        p[lev] = node;
        if (lev < L - 1) node = 2 * node + ((leaf >> (L - 2 - lev)) & 1);
    }
    return p;
}
void cand_add(int bid, int leaf) { for (int n : get_path(leaf)) cand[n].insert(bid); }
void cand_remove(int bid, int leaf) { for (int n : get_path(leaf)) cand[n].erase(bid); }
void cand_update(int bid, int o, int n) { cand_remove(bid, o); cand_add(bid, n); }

void evict_all() {
    for (int node = 1; node <= N; node++) {
        for (auto& [bid, lf] : tree[node])
            if (bid >= 0 && !stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
        tree[node].clear();
    }
    for (int li = L - 1; li >= 0; li--) {
        int first = 1 << li, last = min((1 << (li + 1)) - 1, N), Zn = Z_per_level[li];
        for (int node = first; node <= last; node++) {
            int taken = 0; vector<int> to_evict;
            for (int bid : cand[node]) {
                if (taken >= Zn) break;
                if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
            }
            for (int bid : to_evict) {
                int lf = stash[bid];
                tree[node].push_back({bid, lf});
                stash.erase(bid); cand_remove(bid, lf);
            }
            while ((int)tree[node].size() < Zn) tree[node].push_back({-1, -1});
        }
    }
}

int access(int op, int bid, int new_data) {
    int old_leaf = (bid < Nb) ? pos_map[bid] : leaf_dist(rng);
    int new_leaf = leaf_dist(rng);
    if (bid < Nb) pos_map[bid] = new_leaf;

    auto path = get_path(old_leaf);
    for (int li = 0; li < L; li++) {
        int node = path[li];
        for (auto& [b, lf] : tree[node])
            if (b >= 0 && !stash.count(b)) { stash[b] = lf; cand_add(b, lf); }
        tree[node].clear();
    }
    int result = -1;
    if (bid < (int)pos_map.size() && stash_data.count(bid)) {
        result = stash_data[bid];
        cand_update(bid, stash[bid], new_leaf);
        stash[bid] = new_leaf;
        stash_data[bid] = (op == 1) ? new_data : result;
    } else {
        stash[bid] = new_leaf;
        stash_data[bid] = (op == 1) ? new_data : bid;
        cand_add(bid, new_leaf);
    }
    for (int i = (int)path.size() - 1; i >= 0; i--) {
        int node = path[i], lev = i, Zn = Z_per_level[lev];
        int taken = 0; vector<int> to_evict;
        for (int b : cand[node]) {
            if (taken >= Zn) break;
            if (stash.count(b)) { to_evict.push_back(b); taken++; }
        }
        for (int b : to_evict) {
            int lf = stash[b];
            tree[node].push_back({b, lf});
            stash.erase(b); cand_remove(b, lf);
        }
        while ((int)tree[node].size() < Zn) tree[node].push_back({-1, -1});
    }
    return result;
}

int main() {
    Z_per_level.resize(L);
    for (int li = 0; li < L; li++) {
        int h = L - 1 - li;
        Z_per_level[li] = (h < L0) ? Zbot : Ztop;
    }

    tree.resize(N + 1);
    pos_map.assign(Nb, 0);
    for (int bid = 0; bid < Nb; bid++) {
        int leaf = leaf_dist(rng);
        pos_map[bid] = leaf;
        stash[bid] = leaf;
        stash_data[bid] = bid;
    }
    for (auto& kv : stash)
        for (int n : get_path(kv.second)) cand[n].insert(kv.first);
    printf("Initializing: evict_all() over %d nodes...\n", N); fflush(stdout);
    evict_all();
    printf("Init done. stash=%zu\n\n", stash.size()); fflush(stdout);

    long long total = 50000000LL;
    int warm_rd = 1;

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    printf("================================================================\n");
    printf("  Z43ORAM L0=12 L=%d  Divergence Test\n", L);
    printf("================================================================\n");
    printf("  Configuration:\n");
    printf("    L         = %d (tree height)\n", L);
    printf("    L0        = %d (bottom levels Z=%d)\n", L0, Zbot);
    printf("    Ztop      = %d (upper levels)\n", Ztop);
    printf("    N         = %d (tree nodes)\n", N);
    printf("    Nb        = %d (real blocks, beta=1/3)\n", Nb);
    printf("    Z_per_level (root=level1):\n      ");
    for (int li = 0; li < L; li++) { printf("%d", Z_per_level[li]); if ((li+1)%20==0) printf("\n      "); }
    printf("\n");
    printf("  Experiment:\n");
    printf("    total_reads = 50,000,000 (%.1f full cycles)\n", (double)total/Nb);
    printf("    warmup      = %d round(s)\n", warm_rd);
    printf("  Started: %s\n", tbuf);
    printf("================================================================\n\n");
    fflush(stdout);

    // Warmup
    auto t0 = chrono::steady_clock::now();
    printf("Warmup: %d round(s) (%d accesses)...\n", warm_rd, warm_rd * Nb); fflush(stdout);
    for (int r = 0; r < warm_rd; r++) {
        for (int bid = 0; bid < Nb; bid++) access(0, bid, 0);
        printf("  round %d/%d done\n", r+1, warm_rd); fflush(stdout);
    }
    auto t1 = chrono::steady_clock::now();
    printf("Warmup done (%.0fs).\n\n", chrono::duration<double>(t1 - t0).count()); fflush(stdout);

    // Measurement
    t0 = chrono::steady_clock::now();
    double sum = 0, sumsq = 0, mx = 0, mn = 1e9;
    long long REPORT = max(1LL, total / 200);
    auto last_report = t0;

    FILE* flog = fopen("z43_L12_L26_50M.txt", "w");
    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z43ORAM L0=12 L=%d  Divergence Test\n", L);
    fprintf(flog, "================================================================\n");
    fprintf(flog, "  L=%d  L0=%d  Ztop=%d  Zbot=%d  N=%d  Nb=%d\n", L, L0, Ztop, Zbot, N, Nb);
    fprintf(flog, "  total_reads=50M (%.1f cycles)  warmup=%d\n", (double)total/Nb, warm_rd);
    fprintf(flog, "  Z_per_level (root=level1): ");
    for (int li = 0; li < L; li++) fprintf(flog, "%d", Z_per_level[li]);
    fprintf(flog, "\n  Started: %s\n", tbuf);
    fprintf(flog, "================================================================\n\n");
    fprintf(flog, "%12s %10s %10s %10s %8s %8s\n", "reads", "avg", "sigma", "max", "cycles", "time");

    for (long long i = 0; i < total; i++) {
        int st = (int)stash.size();
        access(0, i % Nb, 0);
        st = (int)stash.size();
        sum += st; sumsq += (double)st * st;
        if (st > mx) mx = st; if (st < mn) mn = st;

        if (i > 0 && i % REPORT == 0) {
            auto t2 = chrono::steady_clock::now();
            double el = chrono::duration<double>(t2 - t0).count();
            double rate = i / el, remain = (total - i) / rate;
            int rh = (int)(remain / 3600), rm = (int)((remain - rh*3600) / 60);
            double avg = sum / i, var = sumsq / i - avg * avg;
            if (var < 0) var = 0;
            double sig = sqrt(var);
            double cycles = (double)i / Nb;
            printf("  [%lld/50M] avg=%.4f sig=%.4f max=%.0f ETA %dh%02dm\n",
                   i/1000000, avg, sig, mx, rh, rm);
            fprintf(flog, "%12lld %10.4f %10.4f %10.0f %7.1f %7.0fs\n",
                    i, avg, sig, mx, cycles, el);
            fflush(flog);
        }
    }

    auto t2 = chrono::steady_clock::now();
    double el = chrono::duration<double>(t2 - t0).count();
    double avg = sum / total, var = sumsq / total - avg * avg;
    if (var < 0) var = 0;
    double sig = sqrt(var);

    printf("\n=== Final ===\n");
    printf("  avg=%.4f  sigma=%.4f  max=%.0f  min=%.0f  time=%.0fs\n", avg, sig, mx, mn, el);
    auto t3 = chrono::system_clock::now();
    time_t tt2 = chrono::system_clock::to_time_t(t3);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt2));
    fprintf(flog, "\n=== Final Results ===\n");
    fprintf(flog, "  avg=%.4f  sigma=%.4f  max=%.0f  min=%.0f  sigma/avg=%.4f\n",
            avg, sig, mx, mn, avg > 0 ? sig/avg : 0);
    fprintf(flog, "  time=%.0fs  Finished: %s\n", el, tbuf);
    fclose(flog);
    printf("\nLog: z43_L12_L26_50M.txt\n");
    return 0;
}
