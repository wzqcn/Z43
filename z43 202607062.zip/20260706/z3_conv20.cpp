/**
 * Z3 L=20 Convergence Test — run until sigma/mean is small.
 * Reports running avg, sigma, sigma/mean every 10M reads.
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z3_conv20.exe z3_conv20.cpp
 * Usage:   z3_conv20.exe [target_ratio] [max_reads_millions]
 *          default: target sigma/avg < 0.1, max 2000M (2B) reads
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

int L = 20, Z = 3;
double beta = 1.0 / 3;
int N = (1 << L) - 1;
int Nb = max(1, (int)(N * beta));

unordered_map<int, int> stash;
vector<int> pos_map;
vector<vector<pair<int,int>>> tree;
unordered_map<int, unordered_set<int>> cand;
mt19937_64 rng(42);
uniform_int_distribution<int> leaf_dist(1, 1 << (L - 1));

vector<int> get_path(int leaf) {
    vector<int> p(L);
    int node = 1;
    for (int lev = 0; lev < L; lev++) {
        p[lev] = node;
        if (lev < L - 1) node = 2 * node + ((leaf >> (L - 2 - lev)) & 1);
    }
    return p;
}
void cand_add(int bid, int leaf) { for (int n : get_path(leaf)) cand[n].insert(bid); }
void cand_remove(int bid, int leaf) { for (int n : get_path(leaf)) cand[n].erase(bid); }
void cand_update(int bid, int o, int n) { cand_remove(bid, o); cand_add(bid, n); }

void evict_all() {
    for (int node = 1; node <= N; node++) {
        for (auto& [bid, lf] : tree[node])
            if (bid >= 0 && !stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
        tree[node].clear();
    }
    for (int li = L - 1; li >= 0; li--) {
        int first = 1 << li, last = min((1 << (li + 1)) - 1, N);
        for (int node = first; node <= last; node++) {
            auto it = cand.find(node);
            if (it == cand.end()) continue;
            int taken = 0;
            vector<int> to_evict;
            for (int bid : it->second) {
                if (taken >= Z) break;
                if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
            }
            for (int bid : to_evict) {
                int lf = stash[bid];
                tree[node].push_back({bid, lf});
                stash.erase(bid);
                cand_remove(bid, lf);
            }
            while ((int)tree[node].size() < Z) tree[node].push_back({-1, -1});
        }
    }
}

int access(int block_id) {
    int old_leaf = (block_id < Nb) ? pos_map[block_id] : leaf_dist(rng);
    int new_leaf = leaf_dist(rng);
    if (block_id < Nb) pos_map[block_id] = new_leaf;
    auto path = get_path(old_leaf);
    for (int li = 0; li < L; li++) {
        int node = path[li];
        for (auto& [bid, lf] : tree[node])
            if (bid >= 0 && !stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
        tree[node].clear();
    }
    if (stash.count(block_id)) {
        cand_update(block_id, stash[block_id], new_leaf);
        stash[block_id] = new_leaf;
    } else {
        stash[block_id] = new_leaf;
        cand_add(block_id, new_leaf);
    }
    for (int i = (int)path.size() - 1; i >= 0; i--) {
        int node = path[i], lev = i;
        auto it = cand.find(node);
        if (it == cand.end()) continue;
        int taken = 0;
        vector<int> to_evict;
        for (int bid : it->second) {
            if (taken >= Z) break;
            if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
        }
        for (int bid : to_evict) {
            int lf = stash[bid];
            tree[node].push_back({bid, lf});
            stash.erase(bid);
            cand_remove(bid, lf);
        }
        while ((int)tree[node].size() < Z) tree[node].push_back({-1, -1});
    }
    return (int)stash.size();
}

int main(int argc, char* argv[]) {
    double target_ratio = (argc >= 2) ? atof(argv[1]) : 0.1;
    long long max_reads = (argc >= 3) ? (long long)atoll(argv[2]) * 1000000 : 2000000000LL;

    tree.resize(N + 1);
    pos_map.assign(Nb, 0);
    for (int bid = 0; bid < Nb; bid++) {
        int leaf = leaf_dist(rng);
        pos_map[bid] = leaf;
        stash[bid] = leaf;
    }
    // rebuilt cand by scanning stash
    for (auto& kv : stash)
        for (int n : get_path(kv.second)) cand[n].insert(kv.first);
    evict_all();

    printf("Z3 L=20 convergence test: Nb=%d  target sigma/avg < %.2f  max_reads=%lldM\n\n",
           Nb, target_ratio, max_reads / 1000000);
    printf("%12s %10s %10s %10s %8s %8s\n", "reads", "avg", "sigma", "sigma/avg", "cycles", "time");
    printf("------------ ---------- ---------- ---------- -------- --------\n");
    fflush(stdout);

    double sum = 0, sumsq = 0;
    long long i = 0;
    auto t0 = chrono::steady_clock::now();
    long long report_interval = 5000000;  // every 5M reads

    while (i < max_reads) {
        int st = access(i % Nb);
        sum += st; sumsq += (double)st * st;
        i++;

        if (i % report_interval == 0 || i == 1) {
            double avg = sum / i;
            double var = sumsq / i - avg * avg;
            if (var < 0) var = 0;
            double sig = sqrt(var);
            double ratio = (avg > 0) ? sig / avg : 999;
            double cycles = (double)i / Nb;
            auto t1 = chrono::steady_clock::now();
            double elapsed = chrono::duration<double>(t1 - t0).count();
            printf("%12lld %10.4f %10.4f %10.4f %7.1f %7.0fs\n",
                   i, avg, sig, ratio, cycles, elapsed);
            fflush(stdout);

            if (i >= Nb * 3 && ratio < target_ratio) {
                printf("\nConverged: sigma/avg = %.4f < %.2f after %lld reads (%.1f cycles)\n",
                       ratio, target_ratio, i, cycles);
                break;
            }
        }
    }

    if (i >= max_reads) {
        double avg = sum / i, var = sumsq / i - avg * avg;
        if (var < 0) var = 0;
        double sig = sqrt(var);
        printf("\nMax reads reached. Final: avg=%.4f sigma=%.4f sigma/avg=%.4f\n",
               avg, sig, sig / avg);
    }

    printf("Done.\n");
    return 0;
}
