/**
 * z3_test.cpp — Z3 stash measurement, L configurable, with progress & ETA.
 *
 * Compile: cl /O2 /std:c++20 /EHsc /nologo /Fe:z3_test.exe z3_test.cpp
 * Usage:   z3_test.exe [L] [reads_M] [warmup_rounds]
 *          default: L=16, 1M reads, 1 warmup round
 */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <chrono>
using namespace std;

class Z3ORAM {
public:
    int L, Z, N, Nb;
    double beta;
    unordered_map<int, int> stash;
    vector<int> pos_map;
    vector<vector<pair<int,int>>> tree;
    unordered_map<int, unordered_set<int>> cand;
    mt19937_64 rng;
    uniform_int_distribution<int> leaf_dist;

    Z3ORAM(int L_, uint64_t seed) : L(L_), Z(3), beta(1.0/3), rng(seed) {
        N = (1 << L) - 1;
        Nb = max(1, (int)(N * beta));
        tree.resize(N + 1);
        pos_map.resize(Nb);
        leaf_dist = uniform_int_distribution<int>(1, 1 << (L - 1));
        for (int bid = 0; bid < Nb; bid++) {
            int leaf = leaf_dist(rng);
            pos_map[bid] = leaf;
            stash[bid] = leaf;
        }
        rebuild_cand();
        evict_all();
    }

    vector<int> get_path(int leaf) const {
        vector<int> p(L);
        int node = 1;
        for (int lev = 0; lev < L; lev++) {
            p[lev] = node;
            if (lev < L - 1) node = 2 * node + ((leaf >> (L - 2 - lev)) & 1);
        }
        return p;
    }
    void rebuild_cand() {
        cand.clear();
        for (auto& kv : stash)
            for (int n : get_path(kv.second)) cand[n].insert(kv.first);
    }
    void cand_add(int bid, int leaf) { for (int n : get_path(leaf)) cand[n].insert(bid); }
    void cand_remove(int bid, int leaf) { for (int n : get_path(leaf)) cand[n].erase(bid); }
    void cand_update(int bid, int o, int n) { cand_remove(bid, o); cand_add(bid, n); }

    void evict_all() {
        for (int node = 1; node <= N; node++) {
            for (auto& [bid, lf] : tree[node])
                if (bid >= 0 && !stash.count(bid)) { stash[bid] = lf; cand_add(bid, lf); }
            tree[node].clear();
        }
        for (int li = L - 1; li >= 0; li--) {
            int first = 1 << li, last = min((1 << (li + 1)) - 1, N);
            for (int node = first; node <= last; node++) {
                auto it = cand.find(node);
                if (it == cand.end()) continue;
                int taken = 0; vector<int> to_evict;
                for (int bid : it->second) {
                    if (taken >= Z) break;
                    if (stash.count(bid)) { to_evict.push_back(bid); taken++; }
                }
                for (int bid : to_evict) {
                    int lf = stash[bid];
                    tree[node].push_back({bid, lf});
                    stash.erase(bid); cand_remove(bid, lf);
                }
                while ((int)tree[node].size() < Z) tree[node].push_back({-1, -1});
            }
        }
    }

    int access(int bid) {
        int old_leaf = (bid < Nb) ? pos_map[bid] : leaf_dist(rng);
        int new_leaf = leaf_dist(rng);
        if (bid < Nb) pos_map[bid] = new_leaf;
        auto path = get_path(old_leaf);
        for (int li = 0; li < L; li++) {
            int node = path[li];
            for (auto& [b, lf] : tree[node])
                if (b >= 0 && !stash.count(b)) { stash[b] = lf; cand_add(b, lf); }
            tree[node].clear();
        }
        if (stash.count(bid)) {
            cand_update(bid, stash[bid], new_leaf);
            stash[bid] = new_leaf;
        } else { stash[bid] = new_leaf; cand_add(bid, new_leaf); }
        for (int i = (int)path.size() - 1; i >= 0; i--) {
            int node = path[i];
            auto it = cand.find(node);
            if (it == cand.end()) continue;
            int taken = 0; vector<int> to_evict;
            for (int b : it->second) {
                if (taken >= Z) break;
                if (stash.count(b)) { to_evict.push_back(b); taken++; }
            }
            for (int b : to_evict) {
                int lf = stash[b];
                tree[node].push_back({b, lf});
                stash.erase(b); cand_remove(b, lf);
            }
            while ((int)tree[node].size() < Z) tree[node].push_back({-1, -1});
        }
        return (int)stash.size();
    }
};

int main() {
    printf("Z3 Stash Test\n");
    printf("  L (tree height, default 16): ");
    char buf[256];
    if (!fgets(buf, sizeof(buf), stdin)) return 1;
    int L = (buf[0] == '\n' || buf[0] == '\r') ? 16 : atoi(buf);
    if (L < 3) L = 3;

    printf("  Reads (millions, default 1): ");
    if (!fgets(buf, sizeof(buf), stdin)) return 1;
    int reads_M = (buf[0] == '\n' || buf[0] == '\r') ? 1 : atoi(buf);
    if (reads_M < 1) reads_M = 1;

    printf("  Warmup rounds (default 1): ");
    if (!fgets(buf, sizeof(buf), stdin)) return 1;
    int warm_rd = (buf[0] == '\n' || buf[0] == '\r') ? 1 : atoi(buf);
    if (warm_rd < 0) warm_rd = 0;
    int Nb = max(1, (int)(((1 << L) - 1) * (1.0 / 3)));
    long long total = (long long)reads_M * 1000000;

    char logfile[256];
    sprintf(logfile, "z3_L%d_%dM.txt", L, reads_M);
    FILE* flog = fopen(logfile, "w");

    auto now = chrono::system_clock::now();
    time_t tt = chrono::system_clock::to_time_t(now);
    char tbuf[64]; strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));

    fprintf(flog, "================================================================\n");
    fprintf(flog, "  Z3 stash test  L=%d  Z=3  beta=1/3\n", L);
    fprintf(flog, "  Nb=%d  total_reads=%dM  warmup_rounds=%d\n", Nb, reads_M, warm_rd);
    fprintf(flog, "  Started: %s\n", tbuf);
    fprintf(flog, "================================================================\n\n");
    fflush(flog);
    printf("Z3 L=%d  Nb=%d  %dM reads  warmup=%d\n", L, Nb, reads_M, warm_rd);

    // ---- Time estimate via calibration ----
    Z3ORAM oram(L, (uint64_t)L * 100 + 3);
    printf("Calibrating speed... ");
    auto tc0 = chrono::steady_clock::now();
    int calib = min(5000, Nb * warm_rd + Nb);
    for (int i = 0; i < calib; i++) oram.access(i % Nb);
    auto tc1 = chrono::steady_clock::now();
    double rate = calib / chrono::duration<double>(tc1 - tc0).count();
    long long total_ops = (long long)Nb * warm_rd + total;
    double est_total = total_ops / rate;
    int eh = (int)(est_total / 3600), em = (int)((est_total - eh*3600) / 60);
    printf("%.0f accesses/s, estimated total: %dh%02dm\n\n", rate, eh, em);

    // Re-init for clean measurement
    oram = Z3ORAM(L, (uint64_t)L * 100 + 3);

    // Warmup
    auto t0 = chrono::steady_clock::now();
    for (int r = 0; r < warm_rd; r++) {
        for (int bid = 0; bid < Nb; bid++) oram.access(bid);
        auto t1 = chrono::steady_clock::now();
        double el = chrono::duration<double>(t1 - t0).count();
        printf("  Warmup %d/%d (%.0fs)\n", r+1, warm_rd, el);
    }

    // Measurement
    t0 = chrono::steady_clock::now();
    double sum = 0, sumsq = 0, mx = 0, mn = 1e9;
    long long REPORT = max(1LL, total / 200);

    for (long long i = 0; i < total; i++) {
        int st = oram.access(i % Nb);
        sum += st; sumsq += (double)st * st;
        if (st > mx) mx = st; if (st < mn) mn = st;

        if (i > 0 && i % REPORT == 0) {
            auto t1 = chrono::steady_clock::now();
            double el = chrono::duration<double>(t1 - t0).count();
            double rate = i / el;
            double remain = (total - i) / rate;
            int rh = (int)(remain / 3600), rm = (int)((remain - rh*3600) / 60);
            double avg = sum / i, var = sumsq / i - avg * avg;
            if (var < 0) var = 0;
            double sig = sqrt(var);
            printf("  [%lld/%lldM] avg=%.4f sig=%.4f max=%.0f ETA %dh%02dm\n",
                   i/1000000, (long long)reads_M, avg, sig, mx, rh, rm);
            fprintf(flog, "  [%lld/%lldM] avg=%.4f sigma=%.4f max=%.0f min=%.0f\n",
                    i/1000000, (long long)reads_M, avg, sig, mx, mn);
            fflush(flog);
        }
    }

    auto t1 = chrono::steady_clock::now();
    double el = chrono::duration<double>(t1 - t0).count();
    double avg = sum / total, var = sumsq / total - avg * avg;
    if (var < 0) var = 0;
    double sig = sqrt(var);

    printf("\n=== Final ===\n");
    printf("  avg=%.4f  sigma=%.4f  max=%.0f  min=%.0f  sigma/avg=%.4f  %.0fs\n",
           avg, sig, mx, mn, avg > 0 ? sig/avg : 0, el);
    fprintf(flog, "\n=== Final Results ===\n");
    fprintf(flog, "  L=%d  total_reads=%dM  warmup=%d\n", L, reads_M, warm_rd);
    fprintf(flog, "  avg=%.4f  sigma=%.4f  max=%.0f  min=%.0f  sigma/avg=%.4f\n",
            avg, sig, mx, mn, avg > 0 ? sig/avg : 0);
    fprintf(flog, "  time=%.0fs\n", el);

    now = chrono::system_clock::now();
    tt = chrono::system_clock::to_time_t(now);
    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", localtime(&tt));
    fprintf(flog, "  Finished: %s\n", tbuf);
    fclose(flog);
    printf("\nLog: %s\n", logfile);
    return 0;
}
