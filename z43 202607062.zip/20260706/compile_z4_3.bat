@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cl /O2 /std:c++20 /EHsc /nologo /Fe:z4_run3.exe z4_run3.cpp
if %ERRORLEVEL% equ 0 (
    echo Build OK: z4_run3.exe
) else (
    echo Build FAILED
)
