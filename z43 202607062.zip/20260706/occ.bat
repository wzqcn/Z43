@echo off
setlocal enabledelayedexpansion

echo ================================================================
echo   Per-Level Occupancy: Z3 vs Z43(L0=8) vs Z431(L0=8)
echo   L=18, 50 million cyclic reads per config
echo   Started: %date% %time%
echo ================================================================

cd /d "%~dp0"

rem --- Compile ---
echo.
echo [Step 0] Compiling occ.cpp ...
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: MSVC environment setup failed!
    exit /b 1
)
cl /O2 /std:c++20 /EHsc /nologo /Fe:occ.exe occ.cpp
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Compilation failed!
    exit /b 1
)
echo Compilation SUCCESS.

rem --- Run ---
echo.
echo ================================================================
echo   Running occupancy experiment: L=1..18, 50M reads each
echo ================================================================
echo.

occ.exe 21 1 1

echo.
echo ================================================================
echo   DONE
echo   Output: occ_L1-18_results.txt
echo   Finished: %date% %time%
echo ================================================================

endlocal
